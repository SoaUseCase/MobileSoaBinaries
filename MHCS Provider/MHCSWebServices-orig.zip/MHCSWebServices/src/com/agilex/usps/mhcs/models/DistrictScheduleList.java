package com.agilex.usps.mhcs.models;

import java.util.ArrayList;
import java.util.Calendar;

public class DistrictScheduleList {

	private ArrayList<DistrictSchedule> collections;
	
	public DistrictScheduleList() {
		this.collections = new ArrayList<DistrictSchedule>();
	}
	
	public void addToList (DistrictSchedule sch ) {
		this.collections.add(sch);
	}
	
	public ArrayList<DistrictSchedule> getDistrictsByReportTime( ) {
		ArrayList<DistrictSchedule> targetList = new ArrayList<DistrictSchedule>();
		System.out.println("getDistrictsByReportTime: collection size: " + collections.size());
		
		int sysMin = Calendar.getInstance().get(Calendar.HOUR_OF_DAY) * 60 + Calendar.getInstance().get(Calendar.MINUTE);
	
		for (DistrictSchedule schedule : collections) {
			System.out.println("DS: SysMin:"+sysMin + " minutes since midnight: "+ schedule.getMinuteSinceMidnight());
			int delta = sysMin - schedule.getMinuteSinceMidnight();
			if ( delta >= 0 && delta < 60 ) {
				System.out.println("Adding schedule to target list. "+ schedule.getDistName());
				targetList.add(schedule);
			}
		}
		
		return targetList;
		
	}
	
}
