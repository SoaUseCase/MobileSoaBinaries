package com.agilex.usps.mhcs.rest;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import oracle.jdbc.OracleTypes;

import com.agilex.usps.mhcs.jdbc.JDBCConnection;
import com.agilex.usps.mhcs.models.CustomError;
import com.google.gson.Gson;
 
@Path("/lookup")
public class LookupService {
 
	private static String 	cachedTrips = "";
	private static Date	cachedDateTime = new Date(0);
	
	@GET
	@Path("/facilities")
	@Produces("application/json")
	public Response returnAreaDistrictFacilityList() {
	
		String resultStr = "";
		try {
			// Retrieve Area, District, and Facility list from database
			resultStr = getFacilitytLookupFromDB();
		} catch (SQLException e) {
			// Create custom error object for return
			CustomError err = new CustomError(e.getErrorCode(), "Getting Facility: " + e.getMessage());
			resultStr = new Gson().toJson(err);
			return Response.status(422).entity(resultStr).header("Access-Control-Allow-Origin", "*").build();
		} 
		return Response.status(200).entity(resultStr).header("Access-Control-Allow-Origin", "*").build();
	}
 
	@GET
	@Path("/tripLibrary")
	@Produces("application/json")
	public Response returnRouteTripPickupLocationList(@HeaderParam("LAST_ROUTE_UPDATE") String timeStamp) {
	
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date lastRouteUpdate = null;
		System.out.println("Getting Trip Library");
		String resultStr = "";
		try {
			// Retrieve Route, Trip, and Pickup Location list from database
			
			// Get the timestamp from DB
			lastRouteUpdate = getRouteTripTimeStamp();
			System.out.println("Input datetime: " + timeStamp + " and database: " + lastRouteUpdate.toString());
        	Date ts;
        	
        	if ( timeStamp == null ) {
        		ts = new Date(0);
        	} else {
	    		try {
					ts = sdf.parse(timeStamp);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					ts = new Date(0);
				}
        	}
        	
        	if ( ts.compareTo(lastRouteUpdate) >= 0 ) { // Mobile is up-to-date
				System.out.println("Mobile device is Up-to-date");
				resultStr = "{}";
        	} else {  // Mobile is out dated, need to update
    			if ( cachedDateTime.compareTo(lastRouteUpdate) >= 0 ) {  // Cache has the latest data
    				System.out.println("Returning cached list");
    				resultStr = cachedTrips;
    			} else {  // Cache is out dated as well
    				System.out.println("Retrieving from database for the list");
    				resultStr = getRouteTripLookupFromDB();
    				cachedTrips = resultStr;
    				cachedDateTime = lastRouteUpdate;
    	        	System.out.println("Cache record is updated " + cachedDateTime.toString());
    			}        		
        	}
		} catch (SQLException e) {
			// Create custom error object for return
			CustomError err = new CustomError(e.getErrorCode(), e.getMessage());
			resultStr = new Gson().toJson(err);
		} 
		return Response.status(200).entity(resultStr).header("LAST_ROUTE_UPDATE", sdf.format(lastRouteUpdate)).build();
	}
	
	private String getFacilitytLookupFromDB() throws SQLException {
		
		Connection dbConnection = null;
		CallableStatement callableStatement = null;
		System.out.println("Calling ALL_FAC_JSON...");

		String getRecordCursorSql = "{call ALL_FAC_JSON(?)}";
		
		try {
			dbConnection = JDBCConnection.getDBConnection();
			callableStatement = dbConnection.prepareCall(getRecordCursorSql);
 
			callableStatement.registerOutParameter(1, OracleTypes.CLOB);

			callableStatement.executeQuery();
			 
			return callableStatement.getString(1);
 
		} catch (SQLException e) {
 
			System.err.println("Fail to load facilities: " + e.getMessage());
			throw e;
 
		} finally {
 
			if (callableStatement != null) {
				callableStatement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
 
		}
 		
	}
	
	private String getRouteTripLookupFromDB() throws SQLException {
		
		Connection dbConnection = null;
		CallableStatement callableStatement = null;
		
		System.out.println("Calling ALL_ROUTES_JSON...");
		String getRecordCursorSql = "{call ALL_ROUTES_JSON(?)}";
		
		try {
			dbConnection = JDBCConnection.getDBConnection();
			callableStatement = dbConnection.prepareCall(getRecordCursorSql);
 
			callableStatement.registerOutParameter(1, OracleTypes.CLOB);

			callableStatement.executeQuery();
			 
			return callableStatement.getString(1);
 
		} catch (SQLException e) {
 
			System.err.println("Fail to load trips: " + e.getMessage());
			throw e;
 
		} finally {
 
			if (callableStatement != null) {
				callableStatement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
 
		}
 		
	}

	private Date getRouteTripTimeStamp() throws SQLException{
		
		Connection dbConnection = null;
		PreparedStatement  statement = null;
		CallableStatement callableStatement = null;
		Date returnDate = null;
		
		String selectSQL = "select VALUE from configuration where name = 'LAST_ROUTE_UPDATE'";
		
		try {
			dbConnection = JDBCConnection.getDBConnection();
			statement = dbConnection.prepareStatement(selectSQL);
			
			System.out.println(selectSQL);
			
			// execute select SQL stetement
			ResultSet rs = statement.executeQuery();

			while (rs.next()) {
				returnDate = rs.getTimestamp("VALUE");
			}
			return returnDate;
			
		} catch (SQLException e) {
			System.err.println("Fail to get from configuration: " + e.getMessage());
			throw e;
		} finally {
 
			if (callableStatement != null) {
				callableStatement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
	}
	
}