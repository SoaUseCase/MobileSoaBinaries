package com.agilex.usps.mhcs.models;

public class KeyValue {
	private String key;
	private String value;
	
	public KeyValue() {}
	
	public KeyValue(String key, String value) {
		this.key = key;
		this.value = value;
	}
	
	public String getKey() {
		return this.key;
	}
	public void setKey(String val) {
		if ( val != null ) {
			this.key = val.toUpperCase();
		} else {
			this.key = "";
		}
			
	}
	
	public String getValue() {
		return this.value;
	}
	public void setValue(String val) {
		if ( val != null ) {
			this.value = val.replaceAll(", ", "\n");
		} else {
			this.value = "";
		} 
	}
}
