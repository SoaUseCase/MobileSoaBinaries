package com.agilex.usps.mhcs.rest;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.agilex.usps.mhcs.scheduler.LateEmailScheduler;
import com.agilex.usps.mhcs.scheduler.MissedEmailScheduler;
import com.agilex.usps.mhcs.scheduler.NightlyDistrictEmailScheduler;
import com.agilex.usps.mhcs.scheduler.PostDateCompleteScheduler;
 
@Path("/schedule")
public class SchedulerService {
	public SchedulerService () {
		LateEmailScheduler.getInstance().run();
		MissedEmailScheduler.getInstance().run();
		NightlyDistrictEmailScheduler.getInstance().run();
		PostDateCompleteScheduler.getInstance().run();
		System.out.println("ScanService kicks off the Late, Missed Email and nightly Schedule Task");
	}
	
	@GET
	@Path("/chitchat")
	@Produces("text/plain")
	public Response sayHello(@HeaderParam("DEVICE_KEY") String deviceKey, @QueryParam("name") String world) {
		String output = "MHCS received : " + world;
		return Response.status(200).entity(output).build();
	}

}
