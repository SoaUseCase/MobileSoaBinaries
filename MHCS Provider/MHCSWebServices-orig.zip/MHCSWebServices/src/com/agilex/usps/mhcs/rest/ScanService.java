package com.agilex.usps.mhcs.rest;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;

import oracle.jdbc.OracleTypes;

import com.agilex.usps.mhcs.jdbc.JDBCConnection;
import com.agilex.usps.mhcs.models.ScanComment;
import com.agilex.usps.mhcs.models.ScanCommentList;
import com.agilex.usps.mhcs.scheduler.LateEmailScheduler;
import com.agilex.usps.mhcs.scheduler.MissedEmailScheduler;
import com.agilex.usps.mhcs.scheduler.NightlyDistrictEmailScheduler;
import com.agilex.usps.mhcs.scheduler.PostDateCompleteScheduler;
import com.agilex.usps.mhcs.utils.DateUtils;
import com.google.gson.Gson;
 
@Path("/scan")
public class ScanService {
 
	public ScanService () {
//		LateEmailScheduler.getInstance().run();
//		MissedEmailScheduler.getInstance().run();
//		NightlyDistrictEmailScheduler.getInstance().run();
//		PostDateCompleteScheduler.getInstance().run();
//		System.out.println("ScanService kicks off the Late, Missed Email and nightly Schedule Task");
	}

	@POST
	@Path("/kickoff")
	@Produces("text/plain")
	public Response kickOff() {
		return Response.status(200).entity("Kicked Off").build();
	}
	
	@POST
	@Path("/postCollection")
	@Consumes("text/plain")
	//@Consumes ("application/json")
	@Produces("text/plain")
	public Response postCollection(@HeaderParam("DEVICE_KEY") String deviceKey, String data ) {
 
		Gson gson = new Gson();
		ScanCommentList list = gson.fromJson(data, ScanCommentList.class);
		
		ArrayList<ScanComment> scList = list.getCollections();
		int total = scList.size();
		String resultStr = "";
		System.out.println("Scanning the trips with " + Integer.toString(total) + " records");
		
		for (ScanComment item : scList) {
			try {
				sendSingleScanCommentToDB(deviceKey, item);
			} catch (SQLException e) {
				resultStr = e.getMessage();
				System.err.println("postCollection error: " + e.getMessage());
			}
		}
		
		if (resultStr.length() > 0) {
			return Response.status(422).entity(resultStr).build();
		}
			
		return Response.status(200).entity("").build();
	}
	
	@POST
	@Path("/tripComplete")
	@Consumes("text/plain")
	//@Consumes ("application/json")
	@Produces("text/plain")
	public Response tripComplete(@HeaderParam("DEVICE_KEY") String deviceKey, String data ) {
 
		System.out.println("Calling trip complete");
		Gson gson = new Gson();
		String resultStr = "";
		ScanComment item = gson.fromJson(data, ScanComment.class);
		
		try {
			sendTripCompleteToDB(deviceKey, item);
		} catch (SQLException e) {
			System.err.println("tripComplete error: " + e.getMessage());
			resultStr = e.getMessage();
		}
		
		if (resultStr.length() > 0) {
			return Response.status(422).entity(resultStr).build();
		}
			
		return Response.status(200).entity("").build();
	}
	
	private void sendScanCommentToDB(String deviceId, String items) throws SQLException {
		
		Connection dbConnection = null;
		CallableStatement callableStatement = null;
		
		String scanCommentStoreProc = "";
		scanCommentStoreProc = "{call POST_COLLECTION(?,?,?)}";
		
		try {
			dbConnection = JDBCConnection.getDBConnection();
			callableStatement = dbConnection.prepareCall(scanCommentStoreProc);
 
			callableStatement.setString(1, deviceId);
			callableStatement.setString(2, items);
			callableStatement.registerOutParameter(3, OracleTypes.VARCHAR);
			
			// executeUpdate does not return result set
			callableStatement.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			throw e;
		} finally {
 
			if (callableStatement != null) {
				callableStatement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
 
		}
 		
	}
	
	private void sendSingleScanCommentToDB(String deviceId, ScanComment item) throws SQLException {
		
		System.out.println("Calling POST_COLLECTION with Device: " + deviceId + " and " + item.toFormatString());
		Connection dbConnection = null;
		CallableStatement callableStatement = null;
		
		String scanCommentStoreProc = "";
		scanCommentStoreProc = "{call POST_COLLECTION(?,?,?,?,?,?,?,?,?)}";
		
		try {
			dbConnection = JDBCConnection.getDBConnection();
			callableStatement = dbConnection.prepareCall(scanCommentStoreProc);
			callableStatement.setString("p_DEVICE_KEY", deviceId);
			callableStatement.setString("p_TRIP_DATE", item.getTripDate());
			callableStatement.setString("p_BAR_CD", item.getBarCode());
			callableStatement.setInt("p_TRIP_ID", item.getTripId());
			callableStatement.setDouble("p_LATITUDE", item.getLatitude());
			callableStatement.setDouble("p_LONGITUDE", item.getLongitude());
			callableStatement.setString("p_COLLECTION_TIME", item.getCollectionTime());
			callableStatement.setString("p_COMMENTS", item.getComments());
			callableStatement.registerOutParameter("p_RETURN_STR", OracleTypes.VARCHAR);
			// executeUpdate does not return result set
			callableStatement.executeUpdate(); 
			String returnStr = callableStatement.getString("p_RETURN_STR");
			if ( returnStr == null ) {
				System.out.println("POST_COLLECTION null p_RETURN_STR");
				return;
			}
			if (returnStr.toUpperCase().indexOf("FAILURE")  >= 0) {
				System.err.println("POST_COLLECTION: " + returnStr + " Fail to post with trip id: " + Integer.toString(item.getTripId()));
				throw new SQLException("Fail to post with trip id: " + Integer.toString(item.getTripId()));// + " and bar code: " + item.getBarCode());
			} else {
				System.out.println("POST_COLLECTION: " + returnStr);
			}
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			throw e;
		} finally {
 
			if (callableStatement != null) {
				callableStatement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
	}
	
	private void sendTripCompleteToDB(String deviceId, ScanComment item) throws SQLException {
		
		Connection dbConnection = null;
		CallableStatement callableStatement = null;
		
		System.out.println("Calling POST_TRIP_COMPLETE with Device: " + deviceId + ", tripID: " + Integer.toString(item.getTripId()));
		String scanCommentStoreProc = "";
		scanCommentStoreProc = "{call POST_TRIP_COMPLETE(?,?,?,?,?)}";
		
		try {
			dbConnection = JDBCConnection.getDBConnection();
			callableStatement = dbConnection.prepareCall(scanCommentStoreProc);
			callableStatement.setString("p_DEVICE_KEY", deviceId);
			callableStatement.setInt("p_TRIP_ID", item.getTripId());
			callableStatement.setString("p_TRIP_DATE", item.getTripDate());
			callableStatement.setString("p_COMPLETION_TIME", item.getCompletionTime());
			callableStatement.registerOutParameter("p_RETURN_STR", OracleTypes.VARCHAR);
			
			// executeUpdate does not return result set
			callableStatement.executeUpdate(); 
			String returnStr = callableStatement.getString("p_RETURN_STR");
			if ( returnStr == null ) {
				System.out.println("POST_TRIP_COMPLETE null p_RETURN_STR");
				return;
			}
			if (returnStr.toUpperCase().indexOf("FAILURE")  >= 0) {
				System.err.println("Trip Complete failed: " + returnStr);
				throw new SQLException("Fail to complete trip: " + Integer.toString(item.getTripId()));
			} else {
				System.out.println("Trip Complete: " + returnStr);
			}
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			throw e;
		} finally {
 
			if (callableStatement != null) {
				callableStatement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
	}
	
	private void updateDevicesTable(String deviceKey) throws SQLException {
		Connection dbConnection = null;
		Statement statement = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		String insertTableSQL = "INSERT INTO DEVICES (ID, DEVICE_KEY, CREATED_BY, CREATED_DATE) " + 
				"VALUES (DEVICE_SEQ.nextval, '" + deviceKey + "', 'Service', " + 
				"to_date('" + dateFormat.format(DateUtils.getStart(new Date())) + "', 'yyyy-MM-dd'))";
 
		try {
			dbConnection = JDBCConnection.getDBConnection();
			statement = dbConnection.createStatement();
 
			System.out.println(insertTableSQL);
 
			// execute insert SQL stetement
			statement.executeUpdate(insertTableSQL);
 
			System.out.println("Record is inserted into DEVICES table!");
 
		} catch (SQLException e) {
 
			System.out.println(e.getMessage());
 
		} finally {
 
			if (statement != null) {
				statement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
 
		}
	}
}