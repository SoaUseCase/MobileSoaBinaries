package com.agilex.usps.mhcs.rest;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.agilex.usps.mhcs.jdbc.JDBCConnection;
import com.agilex.usps.mhcs.models.Collection;
import com.agilex.usps.mhcs.models.CustomError;
import com.agilex.usps.mhcs.models.TripCollectionList;
import com.agilex.usps.mhcs.utils.DateUtils;
import com.google.gson.Gson;

@Path("/")
public class TripService {

	@GET
	@Path("/trips")
	@Produces("application/json")
	public Response getTrips(
			@QueryParam("facility") String facility_id,
			@QueryParam("date") String inputDate) {
		
		String 	resultStr = "";
		int		facId = 0;
		CustomError err = null;
		
		// Check on the inputDate
		Date targetDate = new Date();
		if (inputDate == null) {
			targetDate = new Date();
		}
		else {
			try {
				targetDate = new SimpleDateFormat("yyyy-MM-dd").parse(inputDate);
			} catch (ParseException e) {
				targetDate = new Date();
			}
		}
		
		if (facility_id == null ) {
			err = new CustomError(428, "Facility is required");

		}
		
		try {
			facId = Integer.parseInt(facility_id);
		} catch (NumberFormatException e) {
			err = new CustomError(428, "Facility is not a number");
		}
		
		if ( err != null ) {
			Gson converter = new Gson();
			return Response.status(428).entity(converter.toJson(err)).build();			
		}
		
		try {
			resultStr = getTripListForDate(facId, targetDate);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			return Response.status(422).entity(e.getMessage()).build();
		}
		return Response.status(200).entity(resultStr).header("Access-Control-Allow-Origin", "*").build();
	}

	@GET
	@Path("/tripHistory")
	@Produces("application/json")
	public Response getTripHistory(
		@QueryParam("tripId") String trip_id ) {
		
		String 	resultStr = "";
		int		tripId = 0;
		CustomError err = null;
		
		if (trip_id == null ) {
			err = new CustomError(428, "Trip ID is required");

		}
		
		try {
			tripId = Integer.parseInt(trip_id);
		} catch (NumberFormatException e) {
			err = new CustomError(428, "Trip ID is not a number");
		}
		
		if ( err != null ) {
			Gson converter = new Gson();
			return Response.status(428).entity(converter.toJson(err)).build();			
		}
		
		try {
			resultStr = getTripHistory(tripId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			return Response.status(422).entity(e.getMessage()).build();
		}
		return Response.status(200).entity(resultStr).header("Access-Control-Allow-Origin", "*").build();
	}

	private String getTripListForDate(int facilityId, Date targetDate) throws SQLException {
		
		System.out.println("Get Trip List for fac: " + Integer.toString(facilityId) + " date: " + new SimpleDateFormat("yyyy-MM-dd").format(targetDate));
		Connection dbConnection = null;
		PreparedStatement  statement = null;
		CallableStatement callableStatement = null;
		Boolean isForToday = DateUtils.isToday(targetDate);
		
		String selectSQL = "";
		
		if (isForToday) {
			selectSQL = "select tc.* from TODAYS_COLLECTIONS tc where tc.FAC_ID = ? ORDER BY tc.TRIP_ID, tc.trip_order";
		} else {
			selectSQL = "select tc.* from HISTORICAL_COLLECTIONS tc "
					+ "where tc.FAC_ID = ? and trunc(tc.trip_date) = to_date(?, 'yyyy-mm-dd') "
					+ "ORDER BY tc.TRIP_ID, tc.trip_order";
		}
		
		try {
			dbConnection = JDBCConnection.getDBConnection();
			statement = dbConnection.prepareStatement(selectSQL);
			statement.setInt(1, facilityId);
			if (!isForToday) {
				statement.setString(2, new SimpleDateFormat("yyyy-MM-dd").format(targetDate));
			}
			System.out.println(selectSQL);
			
			// execute select SQL stetement
			ResultSet rs = statement.executeQuery();
			ArrayList<Collection> collList = new ArrayList<Collection>();
			while (rs.next()) {
				Collection coll = new Collection();
				coll.setTripId(rs.getInt("TRIP_ID"));
				coll.setRouteNo(rs.getString("ROUTE_NO"));
				coll.setLegNo(rs.getString("LEG_NO"));
				coll.setTripDate(rs.getDate("TRIP_DATE"));
					
				coll.setTripOrder(rs.getInt("TRIP_ORDER"));
				coll.setEarliestPickupTime(rs.getString("EARLIEST_PICKUP_TIME"));
				coll.setLocationName(rs.getString("LOCATION_NAME"));
				coll.setAddressLine(rs.getString("ADDRESS_LINE"));
				coll.setCityName(rs.getString("CITY_NAME"));
				coll.setStateCd(rs.getString("STATE_CD"));
				coll.setZipCd(rs.getString("ZIP_CD"));
				coll.setTimeZone(rs.getString("TIMZON_CD"));
				coll.setCollectionStatus(rs.getString("COLLECTION_STATUS"));
				coll.setCollectionTime(rs.getTimestamp("COLLECTION_TIME"));
				coll.setCompletionTime(rs.getTimestamp("COMPLETION_TIME"));
				coll.setComments(rs.getString("COMMENTS"));
				collList.add(coll);
			}
			TripCollectionList formatList = new TripCollectionList();
			formatList.importFromRawData(collList);
			
			Gson gson = new Gson();
			return gson.toJson(formatList);
			
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			throw e;
		} finally {
 
			if (callableStatement != null) {
				callableStatement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
	}
	
	private String getTripHistory(int tripId) throws SQLException {
		
		System.out.println("Get Trip History for trip id : " + Integer.toString(tripId));
		Connection dbConnection = null;
		PreparedStatement  statement = null;
		CallableStatement callableStatement = null;
		
		String selectSQL = "select tc.* from HISTORICAL_COLLECTIONS tc where tc.trip_Id = ? and tc.trip_date >= trunc(sysdate) - 60 Order by tc.trip_date desc, tc.trip_order";
		
		try {
			dbConnection = JDBCConnection.getDBConnection();
			statement = dbConnection.prepareStatement(selectSQL);
			statement.setInt(1, tripId);
			System.out.println(selectSQL);
			
			// execute select SQL stetement
			ResultSet rs = statement.executeQuery();

			ArrayList<Collection> collList = new ArrayList<Collection>();
			while (rs.next()) {
				Collection coll = new Collection();
				
				coll.setTripId(rs.getInt("TRIP_ID"));
				coll.setRouteNo(rs.getString("ROUTE_NO"));
				coll.setLegNo(rs.getString("LEG_NO"));
				coll.setTripDate(rs.getDate("TRIP_DATE"));
				coll.setTripOrder(rs.getInt("TRIP_ORDER"));
				coll.setEarliestPickupTime(rs.getString("EARLIEST_PICKUP_TIME"));
				
				coll.setLocationName(rs.getString("LOCATION_NAME"));
				coll.setAddressLine(rs.getString("ADDRESS_LINE"));
				coll.setCityName(rs.getString("CITY_NAME"));
				coll.setStateCd(rs.getString("STATE_CD"));
				coll.setZipCd(rs.getString("ZIP_CD"));

				coll.setTimeZone(rs.getString("TIMZON_CD"));
				coll.setCollectionStatus(rs.getString("COLLECTION_STATUS"));
				coll.setCollectionTime(rs.getTimestamp("COLLECTION_TIME"));
				coll.setCompletionTime(rs.getTimestamp("COMPLETION_TIME"));
				coll.setComments(rs.getString("COMMENTS"));
				collList.add(coll);
			}
			TripCollectionList formatList = new TripCollectionList();
			formatList.importFromRawData(collList);
			
			Gson gson = new Gson();
			return gson.toJson(formatList);
			
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			throw e;
		} finally {
 
			if (callableStatement != null) {
				callableStatement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
	}
}
