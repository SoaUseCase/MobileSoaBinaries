package com.agilex.usps.mhcs.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.PooledConnection;

import oracle.jdbc.pool.OracleConnectionPoolDataSource;

import com.agilex.usps.mhcs.utils.PropertyUtils;

public class JDBCConnection {

	private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
	private static String DB_CONNECTION = "";
	private static String DB_USER = "";
	private static String DB_PASSWORD = "";
	
	public static Connection getDBConnection() throws SQLException {
		
		System.out.println("Get DBConnection");
	/*	Connection dbConnection = null;
		
		try {
 
			Class.forName(DB_DRIVER);

		} catch (ClassNotFoundException e) {
 
			System.err.println("Cannot find " + DB_DRIVER);
 
		}
 
		try {
			readFromPropertyFile();
		} catch (SQLException e1) {
			throw e1;
		}
		
		try {

			dbConnection = DriverManager.getConnection(
				DB_CONNECTION, DB_USER,DB_PASSWORD);
			return dbConnection;
 
		} catch (SQLException e) {
			System.err.println("Fail to connect to DB: " + e.getMessage());
			throw e;
		}
 */
		// Create a OracleConnectionPoolDataSource instance
	    OracleConnectionPoolDataSource ocpds =
	                               new OracleConnectionPoolDataSource();

	    // Set connection parameters
	    readFromPropertyFile();
	    ocpds.setURL(DB_CONNECTION);
	    ocpds.setUser(DB_USER);
	    ocpds.setPassword(DB_PASSWORD);

	    // Create a pooled connection
	    PooledConnection pc  = ocpds.getPooledConnection();

	    // Get a Logical connection
	    Connection conn = pc.getConnection();
	    System.out.println("Return pooled connection");
	    return conn;
	}
	
	private static void readFromPropertyFile() throws SQLException {
		
		if (DB_CONNECTION != "") {
			return;
		}
		
		PropertyUtils propUtil = PropertyUtils.getInstance();
	 
		if ( propUtil != null ) {
			DB_CONNECTION = propUtil.getProperty("DB_CONNECTION");
			DB_USER = propUtil.getProperty("DB_USER");
			DB_PASSWORD = propUtil.getProperty("DB_PASSWORD");
		} else {
			throw new SQLException("Cannot locate config.properties");
		}
	}
	
}
