package com.agilex.usps.mhcs.models;

import java.util.ArrayList;

public class TripCollection {

	private String tripDate;
	private String routeCd;
	private String legNo;
	private int	tripId;
	
	private int totalStops = 0;
	private int onTimeStops = 0;
	private int lateStops = 0;
	private int missedStops = 0;
	private int pendingStops = 0;
	
	private String tripCompleteDate;
	
	private ArrayList<TripStop> tripStops;

	public TripCollection() {
		this.tripStops = new ArrayList<TripStop>();
	}
	
	public void importData(Collection rawData) {
		this.tripDate = rawData.getTripDateAsString();
		this.routeCd  = rawData.getRouteNo();
		this.legNo = rawData.getLegNo();
		this.tripId = rawData.getTripId();
		importStopOnly(rawData);
	}
	
	public void importStopOnly ( Collection rawData) {
		TripStop newStop = new TripStop(rawData);
		
		this.tripStops.add(newStop);
		this.tripCompleteDate = rawData.getCompletionTimeOnly();
	}
	
	public void updateStopCounts() {
		
		this.totalStops = this.tripStops.size();
		
		for (TripStop item : this.tripStops) {
			String status = item.getCollectionStatus().substring(0, 1).toUpperCase();
			if ( status.equals("O") ) {
				this.onTimeStops ++;
			} else if ( status.equals("M") ) {
				this.missedStops ++;
			} else if ( status.equals("L") ) {
				this.lateStops ++;
			} else {
				this.pendingStops ++;
			}
		}
	}
}
