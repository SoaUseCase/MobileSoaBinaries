package com.agilex.usps.mhcs.models;

public class PickupLocation {

	private int 	ID;
	private int 	ROUTE_ID;
	private String 	BAR_CD;
	private String 	NAME;
	private String 	ADDRESS_LINE;
	private String 	CITY_NAME;
	private String 	STATE_CD;
	private String 	ZIP_CD;
	
	public PickupLocation () { }
	
	public PickupLocation (Collection rawData) {
		this.NAME = rawData.getLocationName();
		this.ADDRESS_LINE = rawData.getAddressLine();
		this.CITY_NAME = rawData.getCityName();
		this.STATE_CD = rawData.getStateCd();
		this.ZIP_CD = rawData.getZipCd();
	}
	
	public int getId() {
		return this.ID;
	}
	public void setId(int val) {
		this.ID = val;
	}
	
	public int getRouteId() {
		return this.ROUTE_ID;
	}
	public void setRouteId(int val) {
		this.ROUTE_ID = val;
	}
	
	public String getBarCd() {
		return this.BAR_CD;
	}
	public void setBarCd(String val) {
		this.BAR_CD = val;
	}
	
	public String getName() {
		return this.NAME;
	}
	public void setName(String val) {
		this.NAME = val;
	}
	
	public String getAddressLine() {
		return this.ADDRESS_LINE;
	}
	public void setAddressLine(String val) {
		this.ADDRESS_LINE = val;
	}
	
	public String getCityName() {
		return this.CITY_NAME;
	}
	public void setCityName(String val) {
		this.CITY_NAME = val;
	}
	
	public String getStateCd() {
		return this.STATE_CD;
	}
	public void setStateCd(String val) {
		this.STATE_CD = val;
	}
	
	public String getZipCd() {
		return this.ZIP_CD;
	}
	public void setZipCd(String val) {
		this.ZIP_CD = val;
	}
}
