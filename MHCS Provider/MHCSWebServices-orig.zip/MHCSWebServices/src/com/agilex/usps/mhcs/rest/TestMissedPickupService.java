package com.agilex.usps.mhcs.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.agilex.usps.mhcs.scheduler.MissedEmailThread;
 
@Path("/missPickup")
public class TestMissedPickupService {
 
	@GET
	@Produces("text/plain")
	public Response sayHello(@QueryParam("tripId") String tripId) {
		
		System.out.println("Start missPickup for " + tripId);
		try {
			new Thread(new MissedEmailThread(Integer.parseInt(tripId))).start();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return Response.status(200).entity("Email Failed: " + e.getMessage() + " stack: " + e.getStackTrace()).build();
		}
		return Response.status(200).entity("Mail Success").build();
	}


}