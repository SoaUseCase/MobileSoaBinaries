package com.agilex.usps.mhcs.models;

import java.util.Date;

public class TripStop extends PickupLocation {

	private int		TRIP_ORDER;
	private String	EARLIEST_PICKUP_TIME;
	private String	COLLECTION_TIME;
	private Date	RECEIVED_TIME;
	private String	COMMENTS;
	private String	COLSTAT_CD;
	private String	COLLECTION_STATUS;
	
	public TripStop() {
		super();
	}
	
	public TripStop(Collection rawData) {
		super(rawData);
		
		this.TRIP_ORDER = rawData.getTripOrder();
		this.EARLIEST_PICKUP_TIME = rawData.getEarliestPickupTime();
		this.COLLECTION_TIME = rawData.getCollectionTimeOnly();
		this.RECEIVED_TIME = rawData.getReceivedTime();
		this.COMMENTS = rawData.getComments();
		this.COLSTAT_CD = rawData.getColStatCd();
		this.COLLECTION_STATUS = rawData.getCollectionStatus();
	}
	
	public String getCollectionStatus() {
		return this.COLLECTION_STATUS;
	}
	
}
