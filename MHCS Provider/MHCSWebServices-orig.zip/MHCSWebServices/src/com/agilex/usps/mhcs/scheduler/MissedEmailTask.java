package com.agilex.usps.mhcs.scheduler;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.agilex.usps.mhcs.email.SMTPConnection;
import com.agilex.usps.mhcs.jdbc.JDBCConnection;
import com.agilex.usps.mhcs.models.Collection;
import com.agilex.usps.mhcs.models.EmailObj;
import com.agilex.usps.mhcs.utils.DateUtils;
import com.agilex.usps.mhcs.utils.PropertyUtils;

public class MissedEmailTask extends TimerTask{

	private ArrayList<Collection> collList = new ArrayList<Collection>();
	private static Logger log = Logger.getAnonymousLogger();
	
	@Override
	public void run() {
		log.log(Level.INFO, "Starting thread for Missed Collection Email @ " + new Date().toString());
		processMissedEmails();	
	}
	
	private void processMissedEmails() {
		
		Boolean retrievedSuccess = false;
		try {
			getTodayUnprocessedMissStops();
			log.log(Level.INFO, "There are " + Integer.toString(collList.size()) + " missed pickup records" );
			retrievedSuccess = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			log.log(Level.SEVERE, "Fail to retrieve missed Pickup, error message: " + e.getMessage());
			e.printStackTrace();
			retrievedSuccess = false;
		}
		
		if ( retrievedSuccess && collList.size() > 0 ) {
			
			String currToAddress = "";
			
			for (Collection item : collList) {
				if (item.getMailingList().compareTo(currToAddress) != 0 ) {
					currToAddress = item.getMailingList();
					log.log(Level.INFO, "Construct email for " + currToAddress);
					EmailObj newEmail = constructEmailToSend(currToAddress);
					try {
						SMTPConnection.sendEmail(newEmail,false);
						log.log(Level.INFO, "send email OK");
						updateMissedPickupTable(currToAddress);
						log.log(Level.INFO, "MISSED_PICKUPS table updated as well");
					} catch (Exception e) {
						log.log(Level.SEVERE, "An error occurred when attempting to send an email.  "+ e.getStackTrace());
					}					
				}
			}

		} else {
			// Nothing to send.
		}
	}
	
	private void getTodayUnprocessedMissStops() throws SQLException {
		
		Connection dbConnection = null;
		PreparedStatement  statement = null;
		CallableStatement callableStatement = null;
		
		String selectSQL = "select mc.*, f.MAILING_LIST from missed_collections mc join FACILITIES f on mc.fac_id = f.id order by f.MAILING_LIST, mc.TRIP_ID, trip_order";
		
		collList.clear();
		try {
			dbConnection = JDBCConnection.getDBConnection();
			statement = dbConnection.prepareStatement(selectSQL);
			
			log.log(Level.INFO, selectSQL);
			
			// execute select SQL statement
			ResultSet rs = statement.executeQuery();

			while (rs.next()) {
				Collection coll = new Collection();
				coll.setLocationName(rs.getString("LOCATION_NAME"));
				coll.setAddressLine(rs.getString("ADDRESS_LINE"));
				coll.setCityName(rs.getString("CITY_NAME"));
				coll.setStateCd(rs.getString("STATE_CD"));
				coll.setZipCd(rs.getString("ZIP_CD"));

				coll.setDistId(rs.getInt("DIST_ID"));
				coll.setFacId(rs.getInt("FAC_ID"));
				coll.setRouteNo(rs.getString("ROUTE_NO"));
				coll.setLegNo(rs.getString("LEG_NO"));
				coll.setLocId(rs.getInt("LOC_ID"));
				coll.setTripId(rs.getInt("TRIP_ID"));
				coll.setTripOrder(rs.getInt("TRIP_ORDER"));
				coll.setMailingList(rs.getString("MAILING_LIST"));

				coll.setEarliestPickupTime(rs.getString("EARLIEST_PICKUP_TIME"));
				coll.setCollectionTime(rs.getTimestamp("COLLECTION_TIME"));
				coll.setComments(rs.getString("COMMENTS"));
				collList.add(coll);
			}
			
		} catch (SQLException e) {
			log.log(Level.SEVERE, "Fail to get from missed_collections: " + e.getMessage());
			throw e;
		} finally {
 
			if (callableStatement != null) {
				callableStatement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
	}
	
	private EmailObj constructEmailToSend(String toAddress) {
		PropertyUtils props = PropertyUtils.getInstance();
		Collection coll = collList.get(0);
		String subject = "Alert: Missed stop detected";
		ArrayList<String> addressTo = new ArrayList<String>();
		addressTo.add(coll.getMailingList());
		
		String msgBody = "The following stops were recorded 'Missed': " + "\n\n";
		
		for (Collection item : collList) {
			if ( item.getMailingList().compareTo(toAddress) == 0) {
				msgBody += item.toEmailString() + "\n";
			}
		}
		
		String url = props.getProperty("WEB_PORTAL_URL");
		msgBody += "\n\n\nNavigate to this site " + url + " for more details.";
		
		EmailObj newEmail = new EmailObj(addressTo, subject, msgBody);

		return newEmail;
	}

	private void updateMissedPickupTable(String toAddress) throws SQLException {
		Connection dbConnection = null;
		Statement statement = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			dbConnection = JDBCConnection.getDBConnection();
			statement = dbConnection.createStatement();
			dbConnection.setAutoCommit(false);
			for (Collection item : collList) {
				if (item.getMailingList().compareTo(toAddress) == 0 ) {
					String sqlString = "INSERT INTO MISSED_PICKUPS "
							+ "(LOC_ID, TRIP_ID, TRIP_DATE) VALUES"
							+ "(" + item.getLocId() + ", " + item.getTripId() + ", "
							+ "to_date('" + dateFormat.format(DateUtils.getStart(new Date())) + "', 'yyyy-MM-dd'))";
					statement.addBatch(sqlString);
					log.log(Level.INFO, "added to batch: " + sqlString);
				}
			}

			statement.executeBatch();
			dbConnection.commit();
			log.log(Level.INFO, "Batch committed");
			collList.clear();
		} catch (SQLException e) {
			dbConnection.rollback();
			log.log(Level.SEVERE, "Fail to update MISSED_PICKUPS: " + e.getMessage());
			throw e;
 
		} finally {
 
			if (statement != null) {
				statement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
 
		}
	}

}
