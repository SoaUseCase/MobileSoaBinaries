package com.agilex.usps.mhcs.rest;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.agilex.usps.mhcs.jdbc.JDBCConnection;
 
@Path("/chat")
public class HelloWorldService {
 
	@GET
	@Produces("text/plain")
	public Response sayHello(@HeaderParam("DEVICE_KEY") String deviceKey, @QueryParam("name") String world) {
		String output = "MHCS received : " + world;
		return Response.status(200).entity(output).build();
	}

	@SuppressWarnings("null")
	private String getFacilityMailingList(int facId) throws SQLException {
		
		Connection dbConnection = null;
		PreparedStatement  statement = null;
		
		String selectSQL = "select MAILING_LIST from FACILITIES where ID = ?";
		String mailingList = "";
		
		try {
			dbConnection = JDBCConnection.getDBConnection();
			statement  = dbConnection.prepareStatement(selectSQL);
			statement.setInt(1, facId);
			
			System.out.println(selectSQL);
			
			// execute select SQL stetement
			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				mailingList = rs.getString("MAILING_LIST");
			}
			System.out.println(mailingList);	
			return mailingList;
			
		} catch (SQLException e) {
			System.out.println("GET MAILINGLIST: " + e.getMessage());
			throw e;
		} finally {
 
			if (statement != null) {
				statement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
	}
}