 package com.agilex.usps.mhcs.scheduler;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.agilex.usps.mhcs.jdbc.JDBCConnection;
import com.agilex.usps.mhcs.models.Collection;
import com.agilex.usps.mhcs.models.EmailObj;
import com.agilex.usps.mhcs.utils.DateUtils;

public class MissedEmailThread extends Thread{

	private ArrayList<Collection> collList = new ArrayList<Collection>();

	public MissedEmailThread(int tripId) {
		System.out.println("Starting thread for Missed Collection Email for trip: " + Integer.toString(tripId));
		processMissedEmails(tripId);		
	}

	public void runTest(int tripId)
	{
		System.out.println("Test Missed Email for trip: " + Integer.toString(tripId));
		processMissedEmails(tripId);	
	}
	
	private void processMissedEmails(int tripId) {
		
		Boolean retrievedSuccess = false;
		try {
			getTodayUnprocessedMissStops(tripId);
			System.out.println("There are " + Integer.toString(collList.size()) + " missing pickup records" );
			retrievedSuccess = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println("Fail to retrieve Missing Collection for trip: " + Integer.toString(tripId) + "  Error: " + e.getMessage());
			e.printStackTrace();
			retrievedSuccess = false;
		}
		
		if ( retrievedSuccess && collList.size() > 0 ) {
			System.out.println("Construct email");
			EmailObj newEmail = constructEmailToSend();
			try {
//				SMTPConnection.sendEmail(newEmail);
//				AwsEmail.sendAlertEmail(newEmail);
//				System.out.println("send email OK");
				System.out.println("Email skipped");
				updateMissedPickupTable();
				System.out.println("MISSED_PICKUPS table updated as well");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.err.println(e.getStackTrace());
			}
		} else {
			// Nothing to send.
		}
	}
	
	private void getTodayUnprocessedMissStops(int tripId) throws SQLException {
		
		Connection dbConnection = null;
		PreparedStatement  statement = null;
		CallableStatement callableStatement = null;
		
		String selectSQL = "select mc.*, f.MAILING_LIST from missed_collections mc join FACILITIES f on mc.fac_id = f.id where mc.trip_id = ? order by trip_order";
		
		try {
			dbConnection = JDBCConnection.getDBConnection();
			statement = dbConnection.prepareStatement(selectSQL);
			statement.setInt(1, tripId);
			
			System.out.println(selectSQL);
			
			// execute select SQL stetement
			ResultSet rs = statement.executeQuery();

			while (rs.next()) {
				Collection coll = new Collection();
				coll.setLocationName(rs.getString("LOCATION_NAME"));
				coll.setAddressLine(rs.getString("ADDRESS_LINE"));
				coll.setCityName(rs.getString("CITY_NAME"));
				coll.setStateCd(rs.getString("STATE_CD"));
				coll.setZipCd(rs.getString("ZIP_CD"));

				coll.setDistId(rs.getInt("DIST_ID"));
				coll.setFacId(rs.getInt("FAC_ID"));
				coll.setRouteNo(rs.getString("ROUTE_NO"));
				coll.setLegNo(rs.getString("LEG_NO"));
				coll.setLocId(rs.getInt("LOC_ID"));
				coll.setTripId(rs.getInt("TRIP_ID"));
				coll.setTripOrder(rs.getInt("TRIP_ORDER"));
				coll.setMailingList(rs.getString("MAILING_LIST"));

				coll.setEarliestPickupTime(rs.getString("EARLIEST_PICKUP_TIME"));
				coll.setCollectionTime(rs.getTimestamp("COLLECTION_TIME"));
				coll.setComments(rs.getString("COMMENTS"));
				collList.add(coll);
			}
			
		} catch (SQLException e) {
			System.err.println("Fail to get from missed_collections: " + e.getMessage());
			throw e;
		} finally {
 
			if (callableStatement != null) {
				callableStatement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
	}

	private EmailObj constructEmailToSend() {
		
		Collection coll = collList.get(0);
		String subject = "Alert: Missed stop on Route " + coll.getRouteNo() + "-" + coll.getLegNo();
		ArrayList<String> addressTo = new ArrayList<String>();
		addressTo.add(coll.getMailingList());
		
		String msgBody = "The following stops were recorded 'Missed': " + "\n\n";
		
		for (Collection item : collList) {
			msgBody += item.toEmailString() + "\n";
		}
		
		msgBody += "\n\n\nNavigate to this site http://54.221.231.153:9080/MHCSWebPortal/index.html for more details.";
		
		EmailObj newEmail = new EmailObj(addressTo, subject, msgBody);

		return newEmail;
	}
	
	private void updateMissedPickupTable() throws SQLException {
		Connection dbConnection = null;
		Statement statement = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			dbConnection = JDBCConnection.getDBConnection();
			statement = dbConnection.createStatement();
			dbConnection.setAutoCommit(false);
			for (Collection item : collList) {
				String sqlString = "INSERT INTO MISSED_PICKUPS "
						+ "(LOC_ID, TRIP_ID, TRIP_DATE) VALUES"
						+ "(" + item.getLocId() + ", " + item.getTripId() + ", "
						+ "to_date('" + dateFormat.format(DateUtils.getStart(new Date())) + "', 'yyyy-MM-dd'))";
				statement.addBatch(sqlString);
				System.out.println("added to batch: " + sqlString);

			}

			statement.executeBatch();
			dbConnection.commit();
			System.out.println("Batch committed");
		} catch (SQLException e) {
			dbConnection.rollback();
			System.err.println("Fail to update MISSED_PICKUPS: " + e.getMessage());
			throw e;
 
		} finally {
 
			if (statement != null) {
				statement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
 
		}
	}
}
