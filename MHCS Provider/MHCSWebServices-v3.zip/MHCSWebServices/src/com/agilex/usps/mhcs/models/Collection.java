package com.agilex.usps.mhcs.models;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.agilex.usps.mhcs.utils.DateUtils;

public class Collection {
	
	private int		DIST_ID;
	private int		FAC_ID;
	private int		ROUTE_ID;
	private String	ROUTE_NO;
	private int 	TRIP_ID;
	private String	LEG_NO;
	private int		TRIP_ORDER;
	private String	EARLIEST_PICKUP_TIME;
	private String 	LATEST_PICKUP_TIME;
	private String	LOCATION_NAME;
	private String	ADDRESS_LINE;
	private String	CITY_NAME;
	private String	STATE_CD;
	private String	ZIP_CD;
	private String	COLLECTION_STATUS;
	private Date	COLLECTION_TIME;
	private Date	RECEIVED_TIME;
	private Date	COMPLETION_TIME;
	private String	COMMENTS;
	private String	TIMEZONE;
	private int		LOC_ID;
	private Date	TRIP_DATE;
	private String	COLSTAT_CD;
	
	private String  MAILING_LIST;
	
	public Collection () {}
	
	public int getDistId() {
		return this.DIST_ID;
	}
	public void setDistId(int val) {
		this.DIST_ID = val;
	}

	public int getFacId() {
		return this.FAC_ID;
	}
	public void setFacId(int val) {
		this.FAC_ID = val;
	}
	
	public int getRouteId() {
		return this.ROUTE_ID;
	}
	public void setRouteId(int val) {
		this.ROUTE_ID = val;
	}
	
	public String getRouteNo() {
		return this.ROUTE_NO;
	}
	public void setRouteNo(String val) {
		this.ROUTE_NO = val;
	}
	
	public int getTripId() {
		return this.TRIP_ID;
	}
	public void setTripId(int val) {
		this.TRIP_ID = val;
	}

	public String getLegNo() {
		return this.LEG_NO;
	}
	public void setLegNo(String val) {
		this.LEG_NO = val;
	}
	
	public int getTripOrder() {
		return this.TRIP_ORDER;
	}
	public void setTripOrder(int val) {
		this.TRIP_ORDER = val;
	}

	public String getEarliestPickupTime() {
		return this.EARLIEST_PICKUP_TIME + " " + this.TIMEZONE;
	}
	public void setEarliestPickupTime(String val) {
		this.EARLIEST_PICKUP_TIME = val;
	}

	public String getLatestPickupTime() {
		return this.LATEST_PICKUP_TIME;
	}
	public void setLatestPickupTime(String val) {
		this.LATEST_PICKUP_TIME = val;
	}
	
	public String getLocationName() {
		return this.LOCATION_NAME;
	}
	public void setLocationName(String val) {
		this.LOCATION_NAME = val;
	}
	
	public String getAddressLine() {
		return this.ADDRESS_LINE;
	}
	public void setAddressLine(String val) {
		this.ADDRESS_LINE = val;
	}
	
	public String getCityName() {
		return this.CITY_NAME;
	}
	public void setCityName(String val) {
		this.CITY_NAME = val;
	}
	
	public String getStateCd() {
		return this.STATE_CD;
	}
	public void setStateCd(String val) {
		this.STATE_CD = val;
	}
	
	public String getZipCd() {
		return this.ZIP_CD;
	}
	public void setZipCd(String val) {
		this.ZIP_CD = val;
	}
	
	public String getCollectionStatus() {
		return this.COLLECTION_STATUS;
	}
	public void setCollectionStatus(String val) {
		this.COLLECTION_STATUS = val;
	}
	
	public Date getCollectionTime() {
		return this.COLLECTION_TIME;
	}
	public String getCollectionTimeOnly() {
		if (this.COLLECTION_TIME != null) {
			return getTimeByTimeZone(this.COLLECTION_TIME, this.TIMEZONE) + " " + this.TIMEZONE;
		} else {
			return "";
		}
	}
	public void setCollectionTime(Date val) {
		this.COLLECTION_TIME = val;
	}
	
	public Date getReceivedTime() {
		return this.RECEIVED_TIME;
	}
	public void setReceivedTime(Date val) {
		this.RECEIVED_TIME = val;
	}
	
	public String getCompletionTimeOnly() {
		if (this.COMPLETION_TIME != null) {
			return getTimeByTimeZone(this.COMPLETION_TIME, this.TIMEZONE) + " " + this.TIMEZONE;
		} else {
			return "";
		}
	}
	public void setCompletionTime(Date val) {
		this.COMPLETION_TIME = val;
	}
	
	public String getComments() {
		return this.COMMENTS;
	}
	public void setComments(String val) {
		this.COMMENTS = val;
	}
	
	public String getTimeZone() {
		return this.TIMEZONE;
	}
	public void setTimeZone(String val) {
		this.TIMEZONE = val;
	}
	
	public int getLocId() {
		return this.LOC_ID;
	}
	public void setLocId(int val) {
		this.LOC_ID = val;
	}
	
	public Date getTripDate() {
		return this.TRIP_DATE;
	}
	public void setTripDate(Date val) {
		this.TRIP_DATE = val;
	}
	
	public String getColStatCd() {
		return this.COLSTAT_CD;
	}
	public void setColStatCd(String val) {
		this.COLSTAT_CD = val;
	}

	
	public String getMailingList() {
		return this.MAILING_LIST;
	}
	public void setMailingList(String val) {
		this.MAILING_LIST = val;
	}
	
	public String getTripDateAsString() {
		if (this.TRIP_DATE == null)
			return "";
		
		return (new SimpleDateFormat("MM/dd/yyyy").format(this.TRIP_DATE));
	}
	public String toString() {
		return this.ROUTE_NO + "-" + this.LEG_NO + " at stop " + this.LOCATION_NAME + ", " + this.ADDRESS_LINE + ", " + this.CITY_NAME + " " + this.STATE_CD + " " + this.ZIP_CD;
	}
	
	public String toEmailString() {
		String str = "HCR Route: " + this.ROUTE_NO + "-" + this.LEG_NO + "\n"
				+ "Stop " + Integer.toString(this.TRIP_ORDER) + " @ "
				+ this.LOCATION_NAME + "\n"
				+ this.ADDRESS_LINE + ", " + this.CITY_NAME + " " + this.STATE_CD + " " + this.ZIP_CD + "\n";
		return str;
	}
	
	private String getTimeByTimeZone(Date inTime, String timeZone) {
		Calendar loc = Calendar.getInstance();
		loc.setTime(inTime);
		int offSet = DateUtils.getTimeZoneOffset(timeZone);
		
		loc.add(Calendar.HOUR_OF_DAY, offSet);
		SimpleDateFormat dfTarget = new SimpleDateFormat("HH:mm");	
		return dfTarget.format(loc.getTime());
	}

}
