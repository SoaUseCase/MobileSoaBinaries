package com.agilex.usps.mhcs.scheduler;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimerTask;

import com.agilex.usps.mhcs.email.SMTPConnection;
import com.agilex.usps.mhcs.jdbc.JDBCConnection;
import com.agilex.usps.mhcs.models.DistrictSchedule;
import com.agilex.usps.mhcs.models.DistrictScheduleList;
import com.agilex.usps.mhcs.models.EmailObj;
import com.agilex.usps.mhcs.models.FacilitySummary;
import com.agilex.usps.mhcs.utils.PropertyUtils;
import com.agilex.usps.mhcs.utils.StringHelper;

public class NightlyDistrictEmailTask extends TimerTask{

	public DistrictScheduleList schedules;
	
	@Override
	public void run() {
		System.out.println("Starting thread for Nightly Email @ " + new Date().toString());
		try {
			getSchedules();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			schedules = null;
			System.err.print("Unable to retreive nightly district schedule. Error Message: " + e.getMessage());
		}
		if (!schedules.equals(null)){
			processAllDistrictEmails();
		}
	}
	
	private void getSchedules() throws SQLException {
		System.out.println("Get District Schedules");
		Connection dbConnection = null;
		PreparedStatement  statement = null;
		CallableStatement callableStatement = null;
			
		String selectSQL = "select ID as DIST_ID, NAME as DIST_NAME, MAILING_LIST, REPORT_TIME, TIMZON_CD from districts";
		
		try {
			dbConnection = JDBCConnection.getDBConnection();
			statement = dbConnection.prepareStatement(selectSQL);
			System.out.println(selectSQL);
			
			// execute select SQL stetement
			ResultSet rs = statement.executeQuery();

			this.schedules = new DistrictScheduleList();
			while (rs.next()) {
				DistrictSchedule coll = new DistrictSchedule();
				
				coll.setDistId(rs.getInt("DIST_ID"));
				coll.setDistName(rs.getString("DIST_NAME"));
				coll.setMailingList(rs.getString("MAILING_LIST"));
				coll.setReportTime(rs.getString("REPORT_TIME"));
				coll.setTimeZone(rs.getString("TIMZON_CD"));
				coll.convertToServerTime();
				this.schedules.addToList(coll);
			}
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			throw e;
		} finally {
 
			if (callableStatement != null) {
				callableStatement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
	}
	private void processAllDistrictEmails() {
		
		Boolean retrievedSuccess = false;
		ArrayList<DistrictSchedule> targetList = schedules.getDistrictsByReportTime();
		String distDesc = "There are " + Integer.toString(targetList.size()) + " districts should have reports: ";
		for (DistrictSchedule sch : targetList) {
			distDesc += sch.getDistName() + ", ";
		}
		retrievedSuccess = true;

		if ( retrievedSuccess && targetList.size() > 0 ) {
			
			for (DistrictSchedule item : targetList) {
				processDistrictNightlyEmail(item);
			}

		}
	}

	private void processDistrictNightlyEmail(DistrictSchedule schedule) {
		try {
			ArrayList<FacilitySummary> summList = getFacilitySummaryByDistrict(schedule.getDistId());
			System.out.println("Processing for district: " + schedule.getDistName());
			EmailObj newEmail = constructEmailToSend(schedule, summList);
//			AwsEmail.sendAlertEmail(newEmail);
			SMTPConnection.sendEmail(newEmail, true);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	private void setFacilitySummary(FacilitySummary fs, String stat, int count) {
		if (stat.toUpperCase().compareTo("PENDING") == 0 )  {
			fs.pendingStops = count;
		} else if (stat.toUpperCase().compareTo("ON-TIME") == 0 )  {
			fs.onTimeStops = count;
		} else if (stat.toUpperCase().compareTo("MISSED") == 0 )  {
			fs.missedStops = count;
		} else if (stat.toUpperCase().compareTo("LATE") == 0 )  {
			fs.lateStops = count;
		}

		fs.totalStops = fs.totalStops + count;
	}
	
	private ArrayList<FacilitySummary> getFacilitySummaryByDistrict(int DIST_ID) throws SQLException {
		
		Connection dbConnection = null;
		PreparedStatement  statement = null;
		CallableStatement callableStatement = null;
		
		String selectSQL = "select * from COLLECTION_STATUS_CNTS where DISTRICT_ID = ?";
		
		try {
			dbConnection = JDBCConnection.getDBConnection();
			statement = dbConnection.prepareStatement(selectSQL);
			
			System.out.println(selectSQL);
			statement.setInt(1, DIST_ID);
			// execute select SQL stetement
			ResultSet rs = statement.executeQuery();
			ArrayList<FacilitySummary> summList =  new ArrayList<FacilitySummary>();
			
			String targetFac = "";
			FacilitySummary coll = null;
			
			while (rs.next()) {
				String currFac = rs.getString("FACILITY_NO");
				String currStat = rs.getString("COLLECTION_STATUS");
				int currCount  = rs.getInt("STATUS_COUNT");
				if ( targetFac.compareTo(currFac) != 0 ) {
					targetFac = currFac;
					if (coll != null) {
						summList.add(coll);
					} 
					coll = new FacilitySummary();
				} 
				coll.facNo = currFac;
				coll.facName = rs.getString("FACILITY_NAME");
				setFacilitySummary(coll, currStat, currCount);
			}
			summList.add(coll);
			
			return summList;
		} catch (SQLException e) {
			System.err.println("Fail to get from facility summary: " + e.getMessage());
			throw e;
		} finally {
 
			if (callableStatement != null) {
				callableStatement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
	}

	private EmailObj constructEmailToSend(DistrictSchedule schedule, ArrayList<FacilitySummary> summList) {
		
		String subject = "District Nightly Report: " + schedule.getDistName();
		ArrayList<String> addressTo = new ArrayList<String>();
		addressTo.add(schedule.getMailingList());
		
		String msgBody = "The following records were recorded: " + "\n\n <table border=\"0\">";
		
		msgBody += 	"<tr><td>Facility Name</td>" +
					"<td>Total</td>" +
					"<td>Missed</td>" +
					"<td>Late</td>" +
					"<td>On-Time</td>" +
					"<td>Pending</td>\n"; 

//		msgBody += 	StringHelper.padRight("Facility Name", 50) +
//					StringHelper.padRight("Total", 10) +
//					StringHelper.padRight("Missed", 10) +
//					StringHelper.padRight("Late", 10) +
//					StringHelper.padRight("On-Time", 10) +
//					StringHelper.padRight("Pending", 10) + "\n";
		for (FacilitySummary item : summList) {
			msgBody += "<tr>" + item.toEmailString() + "</tr>";
		}
		
		String url = PropertyUtils.getInstance().getProperty("WEB_PORTAL_URL");
		msgBody += "</table>\n\n\nNavigate to this site " + url + " for more details by the facility.";
		EmailObj newEmail = new EmailObj(addressTo, subject, msgBody);
		return newEmail;
	}
}