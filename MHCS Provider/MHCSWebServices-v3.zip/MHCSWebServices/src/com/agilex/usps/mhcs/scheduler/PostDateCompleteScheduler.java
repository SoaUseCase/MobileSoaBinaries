package com.agilex.usps.mhcs.scheduler;

import java.util.Calendar;
import java.util.Date;
import java.util.Timer;

import com.agilex.usps.mhcs.utils.DateUtils;
import com.agilex.usps.mhcs.utils.PropertyUtils;

public class PostDateCompleteScheduler {

	private static PostDateCompleteScheduler instance = null;
	private static Timer timer = null;
	private static long interval = 1000 * 60 * 60 * 24;
	
	protected PostDateCompleteScheduler() {
		// Exists only to defeat instantiation.
	}
	public static PostDateCompleteScheduler getInstance() {
		if(instance == null) {
			instance = new PostDateCompleteScheduler();
		}
		
		return instance;
	}
	
	public void run() {
		
		if ( timer != null ) {
			stopTimer();
		}

		timer = new Timer();
		
		Date nextSchedule = getNextScheduleDate();
		System.out.println("Next Post_Date_Complete will be " + nextSchedule.toString());
		timer.scheduleAtFixedRate(new PostDateCompleteTask(), nextSchedule, interval);
		//timer.schedule(new PostDateCompleteTask(), nextSchedule);
	}
	
	public void stopTimer() {
		if ( timer != null ) {
			timer.cancel();
		}
	}
	
	private Date getNextScheduleDate() {
		String pdc = PropertyUtils.getInstance().getProperty("POST_DATE_COMPLETION_TIME");
		String[] pdcArray = pdc.split(":");
		Calendar currTime = Calendar.getInstance();
		currTime.setTime(new Date());
		Calendar nextSchedule = Calendar.getInstance();
		nextSchedule.setTime(DateUtils.getStart(new Date()));
		nextSchedule.set(Calendar.HOUR_OF_DAY, Integer.parseInt(pdcArray[0]));
		nextSchedule.set(Calendar.MINUTE, Integer.parseInt(pdcArray[1]));
		if ( currTime.after(nextSchedule) ) {
			nextSchedule.add(Calendar.DAY_OF_MONTH, 1);
		}
		return nextSchedule.getTime();
	}
}
