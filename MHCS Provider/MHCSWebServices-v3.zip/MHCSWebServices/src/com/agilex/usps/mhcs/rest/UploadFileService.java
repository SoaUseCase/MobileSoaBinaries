package com.agilex.usps.mhcs.rest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import oracle.jdbc.OracleTypes;

import com.agilex.usps.mhcs.jdbc.JDBCConnection;
import com.agilex.usps.mhcs.models.KeyValue;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

@Path("/file")
public class UploadFileService {

	private String fileDirectoryPath = null;
	
	@POST
	@Path("/upload")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces("application/xml")
	public Response uploadFile(
			@FormDataParam("file") InputStream uploadedInputStream,
			@FormDataParam("file") FormDataContentDisposition fileDetail) {

		identifyFilePath();
		System.out.println("Start uploading... the default file path is: " + fileDirectoryPath);
		deleteLogFiles();
		Date now = new Date();
		String uploadedFileLocation = Long.toString(now.getTime()) + fileDetail.getFileName();
		// save it
		writeToFile(uploadedInputStream, fullPathFileName(uploadedFileLocation));
		System.out.println("write to file: " + fullPathFileName(uploadedFileLocation));
		
		String output = "";
//		output = readFromFile(fullPathFileName(uploadedFileLocation));
//		output = "<div>SUCCESS Dummy result\n\n" + output + "</div>";
		
		String pStatus = "FAILURE";
		String successStr = "";
		
		successStr = executeSQLLoader(fullPathFileName(uploadedFileLocation));
		if (successStr.compareTo("") != 0) {
			output = "<div>FAILURE\n\nFail to execute SQL Loader:\n" + successStr + "</div>";
			System.out.println("Catch SQL Loader Exception");
			return Response.status(200).entity(output).header("SQLLDR_STATUS", pStatus).build();
		} else {
			File fLog = new File(fullPathFileName("trip_data.log"));
			String logStr = "";
			if(fLog.exists()){
				logStr = readFromFile(fullPathFileName("trip_data.log"));
			} else {
				System.out.println(fullPathFileName("trip_data.log") + " cannot be located after SQLLDR.");
			}
			
			File fBad = new File(fullPathFileName("trip_data.bad"));
			if(fBad.exists()){
				output = "<div>FAILURE\n\ntrip_data.log\n\n" + logStr + "\n\ntrip_data.bad\n\n" + readFromFile(fullPathFileName("trip_data.bad")) + "</div>";
				pStatus = "FAILURE";
			}else{
				System.out.println(fullPathFileName("trip_data.bad") + " cannot be located after SQLLDR.");
				output = "<div>SUCCESS\n\ntrip_data.log\n\n" + logStr + "</div>";
				pStatus = "SUCCESS";
			}
		}
		
		return Response.status(200).entity(output).header("SQLLDR_STATUS", pStatus).build();
	}

	@GET
	@Path("/validate")
	@Produces("text/plain")
	public Response validateUpload() {
		
		KeyValue result = null;
		
		try {
			result = validateRoutes();
			
			if ( result == null ) {
				return Response.status(200).entity("Error occurred during validation: No response message from database.").build();
			} else if ( result.getKey().compareTo("SUCCESS") == 0 ) {
				return Response.status(200).entity("SUCCESS\n\nFile has been validated, ready to commit.\n\n" + result.getValue()).build();
			} else if ( result.getKey().compareTo("FAILURE") == 0 ) {
				return Response.status(200).entity("FAILTURE\n\nError occurred during validation: \n\n" + result.getValue()).build();
			} else { //WARNING
				return Response.status(200).entity("SUCCESS with warning during validation: \n\n" + result.getValue()).build();
			}
		} catch (SQLException e) {
			return Response.status(200).entity("Error occurred during validation: " + e.getMessage()).build();
		}
	}
	
	@GET
	@Path("/merge")
	@Produces("text/plain")
	public Response mergeUpload() {
		
		String result = "";
		
		try {
			result = mergeRoutes();
			
			if ( result == null ) {
				return Response.status(200).entity("Error occurred during commit: No response message from database.").build();
			} else if ( result.toUpperCase().indexOf("SUCCESS") == 0 ) {
				return Response.status(200).entity("SUCCESS\n\nFile has been commit.\n\nPlease check for verification").build();
			} else {
				return Response.status(200).entity("Error occurred during commit: " + result).build();
			}
		} catch (SQLException e) {
			return Response.status(200).entity("<div>Error occurred during commit: " + e.getMessage() + "</div>").build();
		}
	}
	
	private void identifyFilePath() {
		if ( fileDirectoryPath == null) {
			String fPath = this.getClass().getClassLoader().getResource("trip_data_load.ctl").getPath();
			fileDirectoryPath = fPath.substring(0, fPath.indexOf("trip_data_load.ctl"));
			System.out.println("File Directory: " + fileDirectoryPath);
		}
	}
	
	private KeyValue validateRoutes() throws SQLException {
		
		System.out.println("Calling VALIDATE_ROUTES");
		Connection dbConnection = null;
		CallableStatement callableStatement = null;
		
		String scanCommentStoreProc = "";
		scanCommentStoreProc = "{call VALIDATE_ROUTES(?,?)}";
		
		try {
			dbConnection = JDBCConnection.getDBConnection();
			callableStatement = dbConnection.prepareCall(scanCommentStoreProc);
			callableStatement.registerOutParameter("p_STATUS", OracleTypes.VARCHAR);
			callableStatement.registerOutParameter("p_ERRORS", OracleTypes.VARCHAR);
			// executeUpdate does not return result set
			callableStatement.executeUpdate(); 
			
			KeyValue kv = new KeyValue();
			try {
				kv.setKey(callableStatement.getString("p_STATUS"));
			} catch (Exception ex) {
				kv.setKey("FAILURE");
			}
			kv.setValue(callableStatement.getString("p_ERRORS"));
			return kv;

		} catch (SQLException e) {
			System.err.println(e.getMessage());
			throw e;
		} finally {
 
			if (callableStatement != null) {
				callableStatement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
	}
	
	private String mergeRoutes() throws SQLException {
		
		System.out.println("Calling MERGE_ROUTES");
		Connection dbConnection = null;
		CallableStatement callableStatement = null;
		
		String scanCommentStoreProc = "";
		scanCommentStoreProc = "{call MERGE_ROUTES(?)}";
		
		try {
			dbConnection = JDBCConnection.getDBConnection();
			callableStatement = dbConnection.prepareCall(scanCommentStoreProc);
			callableStatement.registerOutParameter("p_STATUS", OracleTypes.VARCHAR);
			// executeUpdate does not return result set
//			callableStatement.executeUpdate(); 
			String result = "SUCCESS";
			try {
//				result = callableStatement.getString("p_STATUS");
			} catch (Exception ex) {
				result = "FAILURE";
			}
			return result;

		} catch (SQLException e) {
			System.err.println(e.getMessage());
			throw e;
		} finally {
 
			if (callableStatement != null) {
				callableStatement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
	}
	
	// save uploaded file to new location
	private void writeToFile(InputStream uploadedInputStream,
			String uploadedFileLocation) {

		try {
			OutputStream out = new FileOutputStream(new File(
					uploadedFileLocation));
			int read = 0;
			byte[] bytes = new byte[1024];

			out = new FileOutputStream(new File(uploadedFileLocation));
			while ((read = uploadedInputStream.read(bytes)) != -1) {
				out.write(bytes, 0, read);
			}
			out.flush();
			out.close();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	private String readFromFile(String fileLocation) {
		BufferedReader br = null;
		String content = "";
		try {
			String sCurrentLine = "";
			br = new BufferedReader(new FileReader(fileLocation));
			while ((sCurrentLine = br.readLine()) != null) {
				content += sCurrentLine + "\n";
			}
 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		
		return content;
	}
	
	private String executeSQLLoader(String fileName) {
//		SQLLDR 	DATA=MHCS_Sioux_Falls_Dakota_Central_6.csv 
//				CONTROL=trip_data_load.ctl 
//				LOG=load.log 
//				BAD=load.bad 
//				USERID=mhcr/mhcr1234@mhcrdb 
//				DISCARD=load.dis 
//				DISCARDMAX=500
		
		String result = "";
	    String sqlldrCmd = "SQLLDR DATA=" + fullPathFileName(fileName) + " " + 
	    	"CONTROL=" + fullPathFileName("trip_data_load.ctl") +
	    	"LOG=" + fullPathFileName("trip_data.log") +
		    "BAD=" + fullPathFileName("trip_data.bad") +
		    "USERID=mhcr/mhcr1234@mhcrdb " +
	    	"DISCARD=" + fullPathFileName("trip_data.dis") +
		    "DISCARDMAX=500";
	    System.out.println("SQLLDR Started");
	    Process proc = null;
		try {
		    Runtime rt = Runtime.getRuntime();
		    proc = rt.exec(sqlldrCmd);
		    System.out.println("SQLLDR Ended");
	    }
	    catch (Exception e) {
	    	System.err.println("SQLLDR: " + e.getMessage());
	    	result = e.getMessage();
	    }finally {
	    	if ( proc != null)
	    		proc.destroy();
            return result;
	    }
		
	}
	
	private void deleteLogFiles() {
		File flog = new File(fullPathFileName("trip_data.log"));
		if (flog.exists()) {
			if(flog.delete()){
				System.out.println(flog.getName() + " is deleted!");
			}else{
				System.out.println("Delete trip_data.log is failed.");
			}
		} else {
			System.out.println(fullPathFileName("trip_data.log") + " does not exist.");
		}

		File fbad = new File(fullPathFileName("trip_data.bad"));
		if (fbad.exists()) {
			if(fbad.delete()){
				System.out.println(fbad.getName() + " is deleted!");
			}else{
				System.out.println("Delete trip_data.bad is failed.");
			}
		} else {
			System.out.println(fullPathFileName("trip_data.bad") + " does not exist.");
		}
	}
	
	private String fullPathFileName(String fileName) {
		return fileDirectoryPath + fileName;
	}
}