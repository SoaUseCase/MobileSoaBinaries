package com.agilex.usps.mhcs.models;

public class ScanComment {

	private int		TRIP_ID;
	private String	TRIP_DATE;
	private String 	BAR_CD;
	private String	COLLECTION_TIME;
	private String 	RECEIVED_TIME;
	private String  COMPLETION_TIME;
	private Double	LATITUDE = 999.0;
	private Double	LONGITUDE = 999.0;
	private String	COMMENTS;
	
	public ScanComment() {}
	
	public String getBarCode() {
		return this.BAR_CD;
	}
	public void setBarCode(String code) {
		this.BAR_CD = code;
	}
	
	public String getCollectionTime() {
		return this.COLLECTION_TIME;
	}
	public void setCollectionTime(String time) {
		this.COLLECTION_TIME = time;
	}

	public String getReceivedTime() {
		return this.RECEIVED_TIME;
	}
	public void setReceivedTime(String time) {
		this.RECEIVED_TIME = time;
	}

	public String getCompletionTime() {
		return this.COMPLETION_TIME;
	}
	public void setCompletionTime(String time) {
		this.COMPLETION_TIME = time;
	}

	public String getComments() {
		return this.COMMENTS;
	}
	public void setComments(String comment) {
		this.COMMENTS = comment;
	}
	
	public Double getLatitude() {
		return this.LATITUDE;
	}
	public void setLatitude(Double val) {
		this.LATITUDE = val;
	}
	
	public Double getLongitude() {
		return this.LONGITUDE;
	}
	public void setLongitude(Double val) {
		this.LONGITUDE = val;
	}
	
	public int getTripId() {
		return this.TRIP_ID;
	}
	public void setTripId(int val) {
		this.TRIP_ID = val;
	}
	
	public String getTripDate() {
		return this.TRIP_DATE;
	}
	public void setTripDate(String val) {
		this.TRIP_DATE = val;
	}
	
	public String toFormatString() {
		return "Trip ID: " + this.TRIP_ID + " | Bar Code: " + this.BAR_CD;
	}
	
}
