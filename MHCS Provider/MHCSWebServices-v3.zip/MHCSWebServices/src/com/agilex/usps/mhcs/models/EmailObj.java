package com.agilex.usps.mhcs.models;

import java.util.ArrayList;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

public class EmailObj {

	private InternetAddress[] addressTo;
	private String subject;
	private String body;
	
	public EmailObj(ArrayList<String> recipients, String subject, String body) {
		addressTo = new InternetAddress[recipients.size()];
        for (int i = 0; i < recipients.size(); i++)
        {
        	try {
				this.addressTo[i] = new InternetAddress(recipients.get(i));
			} catch (AddressException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        
        this.subject = subject;
        this.body = body;
	}
	
	public InternetAddress[] getAddressTo() {
		return this.addressTo;
	}
	
	public String getSubject() {
		return this.subject;
	}
	
	public String getBody() {
		return this.body;
	}
	
}
