package com.agilex.usps.mhcs.email;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
 
public class SendEmail {
	private static String SMPT_HOSTNAME = "email-smtp.us-east-1.amazonaws.com";
	private static String USERNAME = "AKIAJLY23VL7V4DPSF7A";
	private static String PASSWORD = "AvV7/ZGgBXzAieDD+ypWO09XWXQb+13U02EwnV96wVuv";
 
      public static void main(String[] args) throws Exception {
            String to = "michael.zhu@agilex.com";
            String from = "michael.zhu@agilex.com";
            Properties properties = System.getProperties();
            properties.setProperty("mail.smtp.host", SMPT_HOSTNAME);
        
            System.out.println("Before create session");
            
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                  return new PasswordAuthentication(USERNAME, PASSWORD);
            }
        });
        System.out.println("After create session");
        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            message.setSubject("Testing SendEmail");
            message.setText("Test message...");
            System.out.println("Before actual send");
            Transport.send(message);
            System.out.println("Message sent successfully....");
        } catch (MessagingException mex) {
            mex.printStackTrace();
            throw mex;
        }
    }
}