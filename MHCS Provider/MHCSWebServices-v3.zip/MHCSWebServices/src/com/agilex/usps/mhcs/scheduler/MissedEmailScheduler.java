package com.agilex.usps.mhcs.scheduler;

import java.util.Timer;

public class MissedEmailScheduler {

	private static MissedEmailScheduler instance = null;
	private static Timer timer = null;
	private static int delay = 1000 * 60 * 7;
	private static int interval = 1000 * 60 * 10;
	protected MissedEmailScheduler() {
		// Exists only to defeat instantiation.
	}
	public static MissedEmailScheduler getInstance() {
		if(instance == null) {
			instance = new MissedEmailScheduler();
		}
		return instance;
	}
	
	public void run() {
		
		if ( timer != null ) {
			stopTimer();
		}

		timer = new Timer();
		timer.scheduleAtFixedRate(new MissedEmailTask(), delay, interval);
	}
	
	public void stopTimer() {
		if ( timer != null ) {
			timer.cancel();
		}
	}
	
}
