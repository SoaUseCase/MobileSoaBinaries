package com.agilex.usps.mhcs.email;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.DebugGraphics;

import com.agilex.usps.mhcs.models.EmailObj;
import com.agilex.usps.mhcs.utils.PropertyUtils;

public class SMTPConnection {
	private static String SMTP_HOSTNAME = "";
	private static String SMTP_USERNAME = "";
	private static String SMTP_PASSWORD = "";
	private static int SMTP_PORT = 25;
	private static String DEV_TEST = "";
	private static String FROM_EMAIL = "";
	private static String SMTP_DEBUG = "";
	private static Logger log = Logger.getAnonymousLogger();
    public static boolean sendEmail(EmailObj newEmail, boolean isNightly) throws Exception {
    	boolean status = false;
    	//log.log(Level.INFO,"In SMTP EMAIL Send Email Function");
		PropertyUtils propUtil = PropertyUtils.getInstance();
		//log.log(Level.INFO,"Get Properties Ok");
		DEV_TEST = propUtil.getProperty("DEV_TEST");
		//log.log(Level.INFO,"Get DEV_Test value: "+ DEV_TEST);
		SMTP_DEBUG = propUtil.getProperty("SMTP_DEBUG");
		//log.log(Level.INFO,"DEBUG value: "+ SMTP_DEBUG);
    	//if ( SMTP_HOSTNAME.equals("") ) {
    		Properties properties = System.getProperties();
    		log.log(Level.INFO,"Get system propertoes");
        if (DEV_TEST.equals("true")){
        	//log.log(Level.INFO,"DEV_TEST equals true");
    		SMTP_HOSTNAME = propUtil.getProperty("DEV_SMTP_HOSTNAME");
    		SMTP_PORT = Integer.parseInt(propUtil.getProperty("DEV_SMTP_PORT"));
    		FROM_EMAIL    = propUtil.getProperty("DEV_FROM_EMAIL");
    
    		SMTP_USERNAME = propUtil.getProperty("DEV_SMTP_USERNAME");
    		SMTP_PASSWORD = propUtil.getProperty("DEV_SMTP_PASSWORD");        
    		
	        properties.put("mail.smtp.auth", "true");
	        //properties.put("mail.debug", "true");
	        properties.put("mail.smtp.starttls.enable", "true");
	        log.log(Level.INFO,"Sending Email: Set Properties complete");
        } 
        else{
        	//log.log(Level.INFO,"in USPS Settings");
    		SMTP_HOSTNAME = propUtil.getProperty("SMTP_HOSTNAME");
    		SMTP_PORT = Integer.parseInt(propUtil.getProperty("SMTP_PORT"));
    		FROM_EMAIL    = propUtil.getProperty("FROM_EMAIL");
    
    		SMTP_USERNAME = propUtil.getProperty("SMTP_USERNAME");
    		SMTP_PASSWORD = propUtil.getProperty("SMTP_PASSWORD");
    		log.log(Level.INFO,"Send Email: Set USPS Properties complete");
        }
        //log.log(Level.INFO,"Setting connnection to SMTP");
        properties.put("mail.debug", SMTP_DEBUG);
        properties.setProperty("mail.smtp.host", SMTP_HOSTNAME);
        properties.put("mail.smtp.port", SMTP_PORT);  
        properties.put("mail.smtp.from", FROM_EMAIL);
        log.log(Level.INFO,"Send Email: Set SMTP connnection properties complete");
        
        final Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(SMTP_USERNAME, SMTP_PASSWORD);
            }
        });
        //log.log(Level.INFO,"User and Password authenticated, constructing email");
	      final MimeMessage message = new MimeMessage(session);
	        message.setFrom(new InternetAddress(FROM_EMAIL));
	        message.setRecipients(Message.RecipientType.TO, newEmail.getAddressTo());
	        message.setSubject(newEmail.getSubject());
	        
	        if(isNightly){
	        	message.setContent(newEmail.getBody(), "text/html; charset=utf-8");
	        }
	        else{
	        	message.setText(newEmail.getBody());
	        }
	        
	        log.log(Level.INFO,"Send EMail: Email created successfully....");
	        Transport.send(message);
	        log.log(Level.INFO,"Send Email: Message sent successfully....");
	        status = true;  
    	//}
		return status;
	    
	}
}
