package com.agilex.usps.mhcs.models;

import java.util.Calendar;
import java.util.Date;

import com.agilex.usps.mhcs.utils.DateUtils;

public class DistrictSchedule {
	
	private int 	DIST_ID;
	private String	DIST_NAME;
	private String	MAILING_LIST;
	private String	REPORT_TIME;
	private String 	TIME_ZONE;
	private String	SERVER_REPORT_TIME;
	
	public DistrictSchedule () {}
	
	public int getDistId() {
		return this.DIST_ID;
	}
	public void setDistId(int val) {
		this.DIST_ID = val;
	}
	
	public String getDistName () {
		return this.DIST_NAME;
	}
	public void setDistName( String val) {
		this.DIST_NAME = val;
	}

	public String getMailingList () {
		return this.MAILING_LIST;
	}
	public void setMailingList( String val) {
		this.MAILING_LIST = val;
	}
	
	public String getReportTime () {
		return this.REPORT_TIME;
	}
	public void setReportTime( String val) {
		this.REPORT_TIME = val;
	}
	
	public String getTimeZone () {
		return this.TIME_ZONE;
	}
	public void setTimeZone( String val) {
		this.TIME_ZONE = val;
	}
	
	public void convertToServerTime() {
		int origOffset = DateUtils.getTimeZoneOffset(this.TIME_ZONE);
		int servOffset = Calendar.getInstance().getTimeZone().getOffset((new Date()).getTime()) / 1000 / 60 / 60;
		
		int delta = servOffset - origOffset;
		
		int hour = Integer.parseInt(this.REPORT_TIME.substring(0, 2));
		int newHour = (hour + delta) % 24;
		this.SERVER_REPORT_TIME = Integer.toString(newHour) + this.REPORT_TIME.substring(2);
	}
	
	public int getMinuteSinceMidnight() {
		String[] splitStr = this.SERVER_REPORT_TIME.split(":");
		int hour = Integer.parseInt(splitStr[0]);
		int minute = Integer.parseInt(splitStr[1]);
		return hour * 60 + minute;
	}
}
