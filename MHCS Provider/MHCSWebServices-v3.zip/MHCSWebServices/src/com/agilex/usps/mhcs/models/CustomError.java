package com.agilex.usps.mhcs.models;

public class CustomError {

	private int error;
	private String detail;
	
	public CustomError() {}
	
	public CustomError(int err, String detail) {
		this.error = err;
		this.detail = detail;
	}
}
