package com.agilex.usps.mhcs.models;

import java.util.ArrayList;
import java.util.Date;

public class TripCollectionList {

	private ArrayList<TripCollection> collections;
	
	public TripCollectionList() {
		this.collections = new ArrayList<TripCollection>();
	}
	
	public void importFromRawData ( ArrayList<Collection> rawList ) {
		
		if ( rawList.size() == 0 )
			return;
		
		int currTripId = 0;
		Date currTripDate = new Date(0);
		TripCollection newColl = null;
		for (Collection item : rawList) {
			
			if ( item.getTripId() != currTripId || item.getTripDate().compareTo(currTripDate) != 0 ) {
				currTripId = item.getTripId();
				currTripDate = item.getTripDate();
				if ( newColl != null ) {
					this.collections.add(newColl);
				}
				newColl = new TripCollection();
				newColl.importData(item);
			} else {
				newColl.importStopOnly(item);
			}
		}
		
		if (newColl != null)
			this.collections.add(newColl);
		
		for (TripCollection item : this.collections) {
			item.updateStopCounts();
		}
		
	}
}
