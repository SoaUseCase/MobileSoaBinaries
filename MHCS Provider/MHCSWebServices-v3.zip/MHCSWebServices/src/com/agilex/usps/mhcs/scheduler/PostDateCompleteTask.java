package com.agilex.usps.mhcs.scheduler;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimerTask;

import oracle.jdbc.OracleTypes;

import com.agilex.usps.mhcs.jdbc.JDBCConnection;
import com.agilex.usps.mhcs.utils.DateUtils;

public class PostDateCompleteTask extends TimerTask{

	@Override
	public void run() {
		System.out.println("Starting thread for POST DATE COMPLETE @ " + new Date().toString());
		try {
			processPostDateComplete();
		} catch (SQLException e) {
			System.err.println("Fail to execute POST_DATE_COMPLETE:_" + e.getMessage());
		}	
	}
	
	private void processPostDateComplete() throws SQLException {
		
		Connection dbConnection = null;
		CallableStatement callableStatement = null;
		System.out.println("Calling POST_DATE_COMPLETE...");

		String getRecordCursorSql = "{call POST_DATE_COMPLETE(?,?)}";
		
		try {
			dbConnection = JDBCConnection.getDBConnection();
			callableStatement = dbConnection.prepareCall(getRecordCursorSql);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

			String yesterday = sdf.format(DateUtils.getPreviousDate(new Date()));
			callableStatement.setString(1, yesterday);
			callableStatement.registerOutParameter(2, OracleTypes.VARCHAR);

			callableStatement.executeQuery();
		} catch (SQLException e) {
 
			System.err.println("Fail to execute POST_DATA_COMPLETE: " + e.getMessage());
 
		} finally {
 
			if (callableStatement != null) {
				callableStatement.close();
			}
 
			if (dbConnection != null) {
				dbConnection.close();
			}
 
		}
	}
}
