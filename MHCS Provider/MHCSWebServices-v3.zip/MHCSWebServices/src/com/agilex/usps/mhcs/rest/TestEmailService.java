package com.agilex.usps.mhcs.rest;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import com.agilex.usps.mhcs.email.SMTPConnection;
import com.agilex.usps.mhcs.models.EmailObj;

 
@Path("/testMail")
public class TestEmailService {
// 
//	@GET
//	@Path("/AWS")
//	@Produces("text/plain")
////	public Response sendAWSEmail() {
//		
//		try {
//			AwsEmail.sendTestEmail();
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			return Response.status(200).entity("Email Failed: " + e.getMessage() + " stack: " + e.getStackTrace()).build();
//		}
//		return Response.status(200).entity("Mail Sending").build();
//	}

	@GET
	@Path("/SMTP")
	@Produces("text/plain")
	public Response sendSMTPEmail() {
		
		try {
			ArrayList<String> recp = new ArrayList<String>();
			recp.add("michael.zhu@agilex.com");
			EmailObj obj = new EmailObj(recp, "From SMTP", "Hello World");
			SMTPConnection.sendEmail(null,false);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return Response.status(200).entity("Email Failed: " + e.getMessage() + " stack: " + e.getStackTrace()).build();
		}
		return Response.status(200).entity("Mail Sending").build();
	}
	
}