package com.agilex.usps.mhcs.models;

import java.util.ArrayList;

public class ScanCommentList {
	
	private ArrayList<ScanComment> collections;
	
	public ScanCommentList() {
		this.collections = new ArrayList<ScanComment>();
	}
	
	public ArrayList<ScanComment> getCollections() {
		return this.collections;
	}
	
}
