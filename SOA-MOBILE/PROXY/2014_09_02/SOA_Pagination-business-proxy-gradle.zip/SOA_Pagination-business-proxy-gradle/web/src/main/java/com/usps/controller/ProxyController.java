package com.usps.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpMessage;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ProxyController {
    private final Logger log = Logger.getLogger(this.getClass());
	private final static String httpHeaderParamNameForwardUrl = "proxyForwardURL";
	private final static String[] skipRequestHeaders = {"Content-Length"};

	@RequestMapping(value="/proxy", method = RequestMethod.POST)
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		log.debug("Proxy POST request");
        OutputStreamWriter writer = null;
        CloseableHttpClient client = null;
        CloseableHttpResponse clientResponse = null;
        
		try {
			String fowardUrl = getRequestHeaderValue(request, httpHeaderParamNameForwardUrl);
			if (fowardUrl == null) {
				log.error("Proxy server cannot forward to another URL because did not find HTTP header parameter name '" + httpHeaderParamNameForwardUrl + "'.");
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			}
			else {
				log.debug("Proxy server forwardURL = '" + fowardUrl + "'");
		        HttpPost method = new HttpPost(fowardUrl);

		        // create client
		        client = HttpClients.createDefault();	
		        writer = new OutputStreamWriter(response.getOutputStream());

		        // set request headers
		        setRequestHeaders(request, method);
		        
		        // set request entity
		        setRequestEntity(request, method);

	            // execute method
		        clientResponse = client.execute(method);

		        // set response headers
		        setResponseHeaders(response, clientResponse);

	            // write result payload
		        HttpEntity entity = clientResponse.getEntity();
		        if (entity != null) {
		        	response.setStatus(HttpServletResponse.SC_OK);
		        	String payload = EntityUtils.toString(entity);
		        	writer.write(payload);
		            log.debug("Proxy server successful, returning response and status 'OK' and payload = " + payload);
		        }
		        else {
					response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);	
		            log.error("Proxy server error, no repsponse detected, internal server error.");
		        }
			}

		}
		catch (Exception e) {
			log.error(e,e);
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);		
			
			if (writer != null) {
	        	writer.write(e.toString());
			}
		}
		finally {
			if (writer != null) {
				writer.flush();
	            writer.close();
			}
			if (clientResponse != null) {
				clientResponse.close();
			}
			if (client != null) {
				client.close();
			}		
		}
	}

	private void setRequestHeaders(HttpServletRequest servletRequest, HttpMessage newMethod) {
		for (Enumeration<String> e = servletRequest.getHeaderNames(); e.hasMoreElements();) {
			String name = e.nextElement();
			String value = servletRequest.getHeader(name);
			boolean doSkip = false;
			for (String skipHeader : skipRequestHeaders) {
				if (name.equalsIgnoreCase(skipHeader)) {
					log.debug("*** Skipping request header [name: '" + name + "', value : '" + value + "'] ***");
					doSkip = true;
					break;
				}
			}
			if (doSkip) {
				continue;
			}
			newMethod.setHeader(name, value);
			log.debug("Proxy server setting request header to new method [name: '" + name + "', value : '" + value + "']");
		}	
	}
	
	private void setRequestEntity(HttpServletRequest request, HttpPost method) throws Exception {
		String contentType = getRequestHeaderValue(request, "content-type");
		ContentType parsedContentType = ContentType.parse(contentType);
		String payload = getRequestPayload(request);
		log.debug("Proxy server request entity, content-type = '" + contentType + "', parsed content-type = '" + parsedContentType + "', request payload = " + payload);
		StringEntity entity = new StringEntity(payload, parsedContentType);
		method.setEntity(entity);
	}
	
	private String getRequestPayload(HttpServletRequest request) throws Exception {
	    StringBuilder stringBuilder = new StringBuilder();
	    BufferedReader bufferedReader = null;

	    try {
	        InputStream inputStream = request.getInputStream();
	        if (inputStream != null) {
	            bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
	            String line = null;
	            while ((line = bufferedReader.readLine()) != null) {
	                stringBuilder.append(line);
	            }
	        } else {
	            stringBuilder.append("");
	        }
	    } catch (Exception ex) {
	        throw ex;
	    } finally {
	        if (bufferedReader != null) {
                bufferedReader.close();
	        }
	    }

	    return stringBuilder.toString();
	}

	private void setResponseHeaders(HttpServletResponse servletResponse, CloseableHttpResponse responseMethod) {
		for (Header header : responseMethod.getAllHeaders()) {
			String name = header.getName();
			String value = header.getValue();
			servletResponse.setHeader(name, value);
			log.debug("Proxy server setting response header to new method [name: '" + name + "', value : '" + value + "']");
		}
	}
	
	private String getRequestHeaderValue(HttpServletRequest servletRequest, String headerNameInput) {
		for (Enumeration<String> e = servletRequest.getHeaderNames(); e.hasMoreElements();) {
			String headerName = e.nextElement();
			if (headerName.equalsIgnoreCase(headerNameInput)) {
				return servletRequest.getHeader(headerName);
			}
		}	
		return null;
	}
}