package com.agilex.usps.mhcs.scheduler;

import java.util.Timer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LateEmailScheduler {

	private static LateEmailScheduler instance = null;
	private static Timer timer = null;
	private static int delay = 1000 * 60 * 5;
	private static int interval = 1000 * 60 * 10;
	private static Logger log = Logger.getAnonymousLogger();
	
	protected LateEmailScheduler() {
		// Exists only to defeat instantiation.
	}
	public static LateEmailScheduler getInstance() {
		if(instance == null) {
			instance = new LateEmailScheduler();
		}
		return instance;
	}
	
	public void run() {
		
		if ( timer != null ) {
			stopTimer();
		}
		timer = new Timer();
		log.log(Level.INFO,"Start Late Collections check");
		timer.scheduleAtFixedRate(new LateEmailTask(), delay, interval);
	}
	
	public void stopTimer() {
		if ( timer != null ) {
			timer.cancel();
		}
	}
	
}
