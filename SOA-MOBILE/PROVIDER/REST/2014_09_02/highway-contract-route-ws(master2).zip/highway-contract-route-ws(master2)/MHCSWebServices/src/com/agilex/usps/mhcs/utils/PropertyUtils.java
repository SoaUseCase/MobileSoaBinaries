package com.agilex.usps.mhcs.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
public class PropertyUtils {
	
	private static PropertyUtils instance = null;
	private static Properties properties = null;
	private static Logger log = null;
	
	protected PropertyUtils() {
		// Exists only to defeat instantiation.
		log = Logger.getAnonymousLogger();
	}
	public static PropertyUtils getInstance() {
		if(instance == null) {
			instance = new PropertyUtils();
			instance.retrieveProperties();
		}
		return instance;
	}
	private Properties retrieveProperties() {
		if ( properties != null ) {
			return properties;
		}
		
		Properties prop = new Properties();
		ClassLoader loader;
		InputStream inputStream;
		try {
			loader = PropertyUtils.class.getClassLoader();
			inputStream = loader.getResourceAsStream("config.properties");
 
			prop.load(inputStream);
			properties = prop;
			log.log(Level.INFO,"config.properties loaded");
		} catch (IOException e) {
			log.log(Level.SEVERE, "Missing properties file");
			properties = null;
		} finally {
			loader = null;
			inputStream = null;
			prop = null;
		}
		
		return properties;
	}
	
	public String getProperty(String propName) {
		if ( properties == null ) {
			return "";
		}
		
		return properties.getProperty(propName);
	}
}
