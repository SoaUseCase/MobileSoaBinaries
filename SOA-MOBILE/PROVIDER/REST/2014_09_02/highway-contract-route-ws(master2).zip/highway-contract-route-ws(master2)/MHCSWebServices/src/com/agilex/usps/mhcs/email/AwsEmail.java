package com.agilex.usps.mhcs.email;

//import com.amazonaws.auth.AWSCredentials;
//import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider;
//import com.amazonaws.regions.Region;
//import com.amazonaws.regions.Regions;
//import com.amazonaws.services.simpleemail.AWSJavaMailTransport;
//import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
//import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClient;
//import com.amazonaws.services.simpleemail.model.ListVerifiedEmailAddressesResult;
//import com.amazonaws.services.simpleemail.model.VerifyEmailAddressRequest;

public class AwsEmail {
    /*
     * Important: Be sure to fill in an email address you have access to
     *            so that you can receive the initial confirmation email
     *            from Amazon Simple Email Service.
     
    private static final String TO = "michael.zhu@agilex.com";
    private static final String FROM = "beth.adams@agilex.com";
    private static final String BODY = "Hello World!";
    private static final String SUBJECT = "Hello World!";
	private static String FROM_EMAIL = "";
/*
    public static void sendTestEmail() throws IOException {
        /*
         * This credentials provider implementation loads your AWS credentials
         * from a properties file at the root of your classpath.
         *
         * Important: Be sure to fill in your AWS access credentials in the
         *            AwsCredentials.properties file before you try to run this sample.
         *            http://aws.amazon.com/security-credentials
         
        AWSCredentials credentials = new ClasspathPropertiesFileCredentialsProvider().getCredentials();
		AmazonSimpleEmailService ses = new AmazonSimpleEmailServiceClient(credentials);
		Region usWest2 = Region.getRegion(Regions.US_EAST_1);
		ses.setRegion(usWest2);

        /*
         * Before you can send email via Amazon SES, you need to verify that you
         * own the email address from which you???ll be sending email. This will
         * trigger a verification email, which will contain a link that you can
         * click on to complete the verification process.
         
        if (!verifyEmailAddress(ses, FROM) ) {
        	return;
        }

        /*
         * If you've just signed up for SES, then you'll be placed in the Amazon
         * SES sandbox, where you must also verify the email addresses you want
         * to send mail to.
         *
         * You can uncomment the line below to verify the TO address in this
         * sample.
         *
         * Once you have full access to Amazon SES, you will *not* be required
         * to verify each email address you want to send mail to.
         *
         * You can request full access to Amazon SES here:
         * http://aws.amazon.com/ses/fullaccessrequest
         */
        //verifyEmailAddress(ses, TO);


		/*
		 * Setup JavaMail to use the Amazon Simple Email Service by specifying
		 * the "aws" protocol.
		 
		Properties props = new Properties();
		props.setProperty("mail.transport.protocol", "aws");

        /*
         * Setting mail.aws.user and mail.aws.password are optional. Setting
         * these will allow you to send mail using the static transport send()
         * convince method.  It will also allow you to call connect() with no
         * parameters. Otherwise, a user name and password must be specified
         * in connect.
         
        props.setProperty("mail.aws.user", credentials.getAWSAccessKeyId());
        props.setProperty("mail.aws.password", credentials.getAWSSecretKey());

        Session session = Session.getInstance(props);

        try {
            // Create a new Message
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(FROM));
            msg.addRecipient(Message.RecipientType.TO, new InternetAddress(TO));
            msg.setSubject(SUBJECT);
            msg.setText(BODY);
            msg.saveChanges();

            // Reuse one Transport object for sending all your messages
            // for better performance
            Transport t = new AWSJavaMailTransport(session, null);

            t.connect();

            t.sendMessage(msg, null);

            // Close your transport when you're completely done sending
            // all your messages

            t.close();
        } catch (AddressException e) {
            e.printStackTrace();
            System.out.println("Caught an AddressException, which means one or more of your "
                    + "addresses are improperly formatted.");
        } catch (MessagingException e) {
            e.printStackTrace();
            System.out.println("Caught a MessagingException, which means that there was a "
                    + "problem sending your message to Amazon's E-mail Service check the "
                    + "stack trace for more information.");
        }
    }
    
    public static void sendAlertEmail(EmailObj email) throws IOException {
    	
    	if ( FROM_EMAIL.equals("") ) {
    		PropertyUtils propUtil = PropertyUtils.getInstance();
 			FROM_EMAIL    = propUtil.getProperty("FROM_EMAIL");
    	}

        /*
         * This credentials provider implementation loads your AWS credentials
         * from a properties file at the root of your classpath.
         *
         * Important: Be sure to fill in your AWS access credentials in the
         *            AwsCredentials.properties file before you try to run this sample.
         *            http://aws.amazon.com/security-credentials
         */
//        AWSCredentials credentials = new ClasspathPropertiesFileCredentialsProvider().getCredentials();
//		AmazonSimpleEmailService ses = new AmazonSimpleEmailServiceClient(credentials);
//		Region usWest2 = Region.getRegion(Regions.US_EAST_1);
//		ses.setRegion(usWest2);

        /*
         * Before you can send email via Amazon SES, you need to verify that you
         * own the email address from which you???ll be sending email. This will
         * trigger a verification email, which will contain a link that you can
         * click on to complete the verification process.
         */
//        if (!verifyEmailAddress(ses, FROM_EMAIL) ) {
//        	return;
//        }        

        /*
         * If you've just signed up for SES, then you'll be placed in the Amazon
         * SES sandbox, where you must also verify the email addresses you want
         * to send mail to.
         *
         * You can uncomment the line below to verify the TO address in this
         * sample.
         *
         * Once you have full access to Amazon SES, you will *not* be required
         * to verify each email address you want to send mail to.
         *
         * You can request full access to Amazon SES here:
         * http://aws.amazon.com/ses/fullaccessrequest
         */
        //verifyEmailAddress(ses, TO);


		/*
		 * Setup JavaMail to use the Amazon Simple Email Service by specifying
		 * the "aws" protocol.
		 
		Properties props = new Properties();
		props.setProperty("mail.transport.protocol", "aws");

        /*
         * Setting mail.aws.user and mail.aws.password are optional. Setting
         * these will allow you to send mail using the static transport send()
         * convince method.  It will also allow you to call connect() with no
         * parameters. Otherwise, a user name and password must be specified
         * in connect.
//         */
//        props.setProperty("mail.aws.user", credentials.getAWSAccessKeyId());
//        props.setProperty("mail.aws.password", credentials.getAWSSecretKey());
//
//        Session session = Session.getInstance(props);
//
//        try {
//            // Create a new Message
//            Message msg = new MimeMessage(session);
//            msg.setFrom(new InternetAddress(FROM));
////            msg.addRecipient(Message.RecipientType.TO, new InternetAddress(TO));
//            msg.addRecipients(Message.RecipientType.TO, email.getAddressTo());
//            msg.setSubject(email.getSubject());
//            msg.setText(email.getBody());
//            msg.saveChanges();

            // Reuse one Transport object for sending all your messages
            // for better performance
//            Transport t = new AWSJavaMailTransport(session, null);
//
//            t.connect();
//
//            t.sendMessage(msg, null);

            // Close your transport when you're completely done sending
            // all your messages
//
//            t.close();
//        } catch (AddressException e) {
//            e.printStackTrace();
//            System.out.println("Caught an AddressException, which means one or more of your "
//                    + "addresses are improperly formatted.");
//        } catch (MessagingException e) {
//            e.printStackTrace();
//            System.out.println("Caught a MessagingException, which means that there was a "
//                    + "problem sending your message to Amazon's E-mail Service check the "
//                    + "stack trace for more information.");
//        }
//    }
    
    /**
     * Sends a request to Amazon Simple Email Service to verify the specified
     * email address. This triggers a verification email, which will contain a
     * link that you can click on to complete the verification process.
     *
     * @param ses
     *            The Amazon Simple Email Service client to use when making
     *            requests to Amazon SES.
     * @param address
     *            The email address to verify.
     
    private static Boolean verifyEmailAddress(AmazonSimpleEmailService ses, String address) {
        ListVerifiedEmailAddressesResult verifiedEmails = ses.listVerifiedEmailAddresses();
        if (verifiedEmails.getVerifiedEmailAddresses().contains(address)) return true;

        ses.verifyEmailAddress(new VerifyEmailAddressRequest().withEmailAddress(address));
        System.out.println("Please check the email address " + address + " to verify it");
        
        return false;
//        System.exit(0);
    }
 */   
}
