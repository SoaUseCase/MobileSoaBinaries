package com.agilex.usps.mhcs.models;

import com.agilex.usps.mhcs.utils.StringHelper;

public class FacilitySummary {
	
	public String facNo;
	public String facName;
	public String facZipCd;
	
	public int totalStops = 0;
	public int onTimeStops = 0;
	public int lateStops = 0;
	public int missedStops = 0;
	public int pendingStops = 0;
	
	public String toEmailString() {
		return 	"<td>"+ this.facName +"</td>" + 
				"<td>"+ Integer.toString(this.totalStops) +"</td>" + 
				"<td>"+ Integer.toString(this.missedStops) +"</td>" + 
				"<td>"+ Integer.toString(this.lateStops) +"</td>" + 
				"<td>"+ Integer.toString(this.onTimeStops) +"</td>" + 
				"<td>"+ Integer.toString(this.pendingStops) +"</td>";
	}
}
