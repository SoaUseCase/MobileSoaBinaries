package com.agilex.usps.mhcs.scheduler;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Timer;

import com.agilex.usps.mhcs.jdbc.JDBCConnection;
import com.agilex.usps.mhcs.models.DistrictSchedule;
import com.agilex.usps.mhcs.models.DistrictScheduleList;
import com.agilex.usps.mhcs.utils.DateUtils;

public class NightlyDistrictEmailScheduler {

	private static NightlyDistrictEmailScheduler instance = null;
	private static Timer timer = null;
	private static int interval = 1000 * 60 * 60;
	private static DistrictScheduleList schedules = new DistrictScheduleList();
	
	protected NightlyDistrictEmailScheduler() {
		// Exists only to defeat instantiation.
	}
	public static NightlyDistrictEmailScheduler getInstance() {
		if(instance == null) {
			instance = new NightlyDistrictEmailScheduler();
		}
		return instance;
	}
	
	public void run() {
		
		if ( timer != null ) {
			stopTimer();
		}

		timer = new Timer();

		//try {
			//getSchedules();

			Date nextHour = DateUtils.getNextHour(null);
			System.out.println("Nightly will start to run on " + nextHour.toString());
			NightlyDistrictEmailTask task = new NightlyDistrictEmailTask();
			//task.schedules = schedules;
			timer.scheduleAtFixedRate(task, nextHour, interval);

//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}
	
	public void stopTimer() {
		if ( timer != null ) {
			timer.cancel();
		}
	}

}
