package com.usps.api.rest.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.validation.ConstraintValidator;
import javax.validation.Valid;

import org.codehaus.jackson.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.usps.api.annotation.Paginate;
import com.usps.exception.PaginateMethodArgumentNotValidException;
import com.usps.core.model.PaginateRequest;
import com.usps.core.model.PaginateResponse;
import com.usps.core.model.PaginateResponseStatus;
import com.usps.core.service.JSONService;
import com.usps.core.service.PaginateService;
import com.usps.domain.Constants;

/**
 * To get json/xml do one of the following in the HTTP Request Headers:
 * 
 * Accept: application/json
 * Accept: application/xml
 * 
 */
@RestController
@RequestMapping(value = Constants.URL_API_PAGINATE)
public class PaginateAPIController extends APIController {
	@Value("${error.validation.paginate_request_parameters_not_valid}")
	private String defaultPaginateRequestParametersErrorMsg;
	@Autowired
	private PaginateService paginateService;
	@Autowired
	private JSONService jsonService;
	@Autowired
	private ConstraintValidator<Paginate, PaginateRequest> paginateValidator;	
	
	@RequestMapping(method = RequestMethod.GET, produces={"application/json"})
	@ResponseStatus(HttpStatus.OK)	
	public PaginateResponse paginateGet(@RequestParam(value = "json", required = true) String json) throws PaginateMethodArgumentNotValidException {		
		log.debug("Paginate GET, json string...\n" + json + "");
		
		PaginateMethodArgumentNotValidException ex = new PaginateMethodArgumentNotValidException("HTTP GET 'json' parameter is not valid, "
				+ "probably JSON string is not formatted correctly.  "
				+ "Cannot create PaginateRequest object from json string.");
		
		PaginateRequest paginateRequest;	
		try {
			paginateRequest = jsonService.getObject(json, PaginateRequest.class);
			log.debug("Paginate GET, created paginate request object...\n" + paginateRequest + "");
		} catch (JsonProcessingException e) {
			throw ex;
		} catch (IOException e) {
			throw ex;
		}

		if (!paginateValidator.isValid(paginateRequest, null)) {
			throw ex;
		}

		return getPaginateResponse(paginateRequest);
	}
	
	/**
	 * headers = {"Content-type=application/json"} The content received in the
	 * post request are in JSON format.
	 * 
	 * @param paginateRequest
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = {"Content-type="+MediaType.APPLICATION_JSON_VALUE}, produces={"application/json"})
	@ResponseStatus(HttpStatus.OK)
	public PaginateResponse paginatePost(@Valid @RequestBody PaginateRequest paginateRequest) {
		log.debug("Paginate POST, paginateRequest = " + paginateRequest);
		return getPaginateResponse(paginateRequest);
	}
	
	private PaginateResponse getPaginateResponse(PaginateRequest paginateRequest) {
		List<String> results = paginateService.paginate(Integer.parseInt(paginateRequest.getPageNumber()), Integer.parseInt(paginateRequest.getDisplayPages()), paginateRequest.getPages());		
		return new PaginateResponse(PaginateResponseStatus.OK, results);
	}
	
	/**
	 * 
	 * @param ex
	 * @return
	 */
    @ExceptionHandler(PaginateMethodArgumentNotValidException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public Map<String, Object> handlePaginateMethodArgumentNotValidException(PaginateMethodArgumentNotValidException ex) {
        return handleOtherException(ex);
    }

	@Override
	protected String getDefaultMethodArgumentNotValidExceptionMsg() {
		return defaultPaginateRequestParametersErrorMsg;
	}
}