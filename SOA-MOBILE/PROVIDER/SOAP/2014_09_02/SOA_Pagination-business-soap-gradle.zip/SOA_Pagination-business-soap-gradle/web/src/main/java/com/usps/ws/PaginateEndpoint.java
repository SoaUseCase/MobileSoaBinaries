package com.usps.ws;

import java.io.StringWriter;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.usps.core.model.PaginateResponseStatus;
import com.usps.core.service.PaginateService;
import com.usps.exception.PaginateMethodArgumentNotValidException;
import com.usps.validator.PaginateValidator;
import com.usps.validator.PaginateValidatorImpl.PaginateValidatorResult;
import com.usps.ws.paginate.PageListType;
import com.usps.ws.paginate.PaginateWSRequest;
import com.usps.ws.paginate.PaginateWSResponse;

@Endpoint
public class PaginateEndpoint {
    private final Logger log = Logger.getLogger(this.getClass());
	private static final String NAMESPACE_URI = "http://usps.com/ws/paginate";
	@Autowired
	private PaginateValidator paginateValidator;
	@Autowired
	private PaginateService paginateService;

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "paginateWSRequest")
	@ResponsePayload
	public PaginateWSResponse paginate(@RequestPayload PaginateWSRequest request) throws PaginateMethodArgumentNotValidException, JAXBException {
		log.debug("Paginate SOAP request => " + getXML(request));
		
		int pageNumber = request.getPageNumber().intValue();
		int displayPages = request.getDisplayPages().intValue();
		List<String> pages = request.getPages().getPage();
		
		PaginateValidatorResult validationResult = paginateValidator.isValid(pageNumber, displayPages, pages);
		if (!validationResult.isValid()) {
			throw new PaginateMethodArgumentNotValidException("SOAP paginate request is not valid.  Cannot perform operation.  Error message => " + validationResult.getErrorMsg());
		}

		PaginateWSResponse response = getResponse(pageNumber, displayPages, pages);
		log.debug("Paginate SOAP response => " + getXML(response));
		return response;
	}

	private PaginateWSResponse getResponse(int pageNumber, int displayPages, List<String> pages) {
		List<String> results = paginateService.paginate(pageNumber, displayPages, pages);	
		PageListType newPages = new PageListType();
		newPages.getPage().addAll(results);
		
		PaginateWSResponse response = new PaginateWSResponse();
		response.setStatus(PaginateResponseStatus.OK.toString());
		response.setPages(newPages);

		return response;
	}
	
    private String getXML(Object o) throws JAXBException {
        Marshaller marshaller = JAXBContext.newInstance(o.getClass()).createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        StringWriter w = new StringWriter();
        marshaller.marshal(o, w);
        return w.toString();
    }
}
