#!/bin/sh

# This is setup for a MAC shell script
# Don't forget to make the file executable by "chmod +x <filename>"
echo

curl --request POST --header "content-type: text/xml" -d @paginateSOAP.xml http://localhost:9080/soaPagination-business-soap-1.0/ws/paginateService

echo
echo