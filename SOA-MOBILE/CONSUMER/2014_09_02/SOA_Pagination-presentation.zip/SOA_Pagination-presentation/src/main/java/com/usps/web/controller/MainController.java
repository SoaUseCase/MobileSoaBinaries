package com.usps.web.controller;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.usps.domain.Constants;

@Controller
public class MainController {
    private final Logger log = Logger.getLogger(this.getClass());
    private final static String CORS_PATH = "Cors";
    private final static String JQUERY_CORS_PATH = "JqueryCors";
    private final static String PROXY_PATH = "Proxy";
    private final static String SOAP_JQUERY_PATH = "soapJQuery";
    private final static String SOAP_PROXY_PATH = "soapProxy";
    private final static String SOAP_XMLHTTPREQUEST_PATH = "soapXmlHttpRequest";

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String home() {
        return index();
    }

    @RequestMapping(value = "/" + Constants.URL_INDEX + Constants.EXTENSTION_HTM, method = RequestMethod.GET)
    public String index() {
        log.debug("Viewing " + Constants.URL_INDEX);
        return Constants.URL_INDEX;
    }

    @RequestMapping(value = "/" + Constants.URL_PAGINATION + Constants.EXTENSTION_HTM, method = RequestMethod.GET)
    public String pagination() {
        log.debug("Viewing " + Constants.URL_PAGINATION);
        return Constants.URL_PAGINATION;
    }

    @RequestMapping(value = "/" + Constants.URL_PAGINATION + CORS_PATH + Constants.EXTENSTION_HTM, method = RequestMethod.GET)
    public String paginationCors() {
        log.debug("Viewing " + Constants.URL_PAGINATION + CORS_PATH);
        return Constants.URL_PAGINATION + CORS_PATH;
    } 

    @RequestMapping(value = "/" + Constants.URL_PAGINATION + JQUERY_CORS_PATH + Constants.EXTENSTION_HTM, method = RequestMethod.GET)
    public String paginationJqueryCors() {
        log.debug("Viewing " + Constants.URL_PAGINATION + JQUERY_CORS_PATH);
        return Constants.URL_PAGINATION + JQUERY_CORS_PATH;
    }
    
    @RequestMapping(value = "/" + Constants.URL_PAGINATION + PROXY_PATH + Constants.EXTENSTION_HTM, method = RequestMethod.GET)
    public String paginationProxy() {
        log.debug("Viewing " + Constants.URL_PAGINATION + PROXY_PATH);
        return Constants.URL_PAGINATION + PROXY_PATH;
    }

    @RequestMapping(value = "/" + SOAP_JQUERY_PATH + Constants.EXTENSTION_HTM, method = RequestMethod.GET)
    public String paginationSoapJquery() {
        log.debug("Viewing " + SOAP_JQUERY_PATH);
        return SOAP_JQUERY_PATH;
    }

    @RequestMapping(value = "/" + SOAP_XMLHTTPREQUEST_PATH + Constants.EXTENSTION_HTM, method = RequestMethod.GET)
    public String paginationSoapXmlHttpRequest() {
        log.debug("Viewing " + SOAP_XMLHTTPREQUEST_PATH);
        return SOAP_XMLHTTPREQUEST_PATH;
    }
    
    @RequestMapping(value = "/" + SOAP_PROXY_PATH + Constants.EXTENSTION_HTM, method = RequestMethod.GET)
    public String paginationSoapProxyRequest() {
        log.debug("Viewing " + SOAP_PROXY_PATH);
        return SOAP_PROXY_PATH;
    }
    
	public String getCORS_PATH() {
		return CORS_PATH;
	}

	public String getJQUERY_CORS_PATH() {
		return JQUERY_CORS_PATH;
	}

	public String getPROXY_PATH() {
		return PROXY_PATH;
	}

	public String getSOAP_JQUERY_PATH() {
		return SOAP_JQUERY_PATH;
	}

	public String getSOAP_XMLHTTPREQUEST_PATH() {
		return SOAP_XMLHTTPREQUEST_PATH;
	}

	public String getSOAP_PROXY_PATH() {
		return SOAP_PROXY_PATH;
	}  
}