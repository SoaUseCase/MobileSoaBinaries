function doSoapJQuery() {
	if (!document.implementation) {
		alert("Browser does not support creating xml object, thus cannot send SOAP request!");
		return;
	}
	
	resetPanels();
	
    var myHeaders = {};
    myHeaders[$("#consumerIDHeaderName").val()] = $("#consumerIDValue").val();
    myHeaders[$("#contextIDHeaderName").val()] = $("#contextIDValue").val();

	$.soap({
	    url: $("#serviceEndpoint").val(),
	    method: $("#serviceMethod").val(),
	    data: getXMLRequestInput(),
	    HTTPHeaders: myHeaders,
//	    enableLogging: true,
	    
//	    data: {
//	    	displayPages: "2",
//    		pageNumber: "1",
//			xmlns: "http://usps.com/ws/paginate",
//			pages: {
//				page : ["1","2","3","4","5","6"]
//			}
//	    },
//	    noPrefix: false,                                // set to true if you don't want the namespaceQualifier to be the prefix for the nodes in params. defaults to false (optional)
//	    namespaceQualifier: 'pns',
//	    namespaceURL: 'http://usps.com/ws/paginate',
//	    elementName: 'paginateWSRequest',              // override 'method' as outer element (optional)
	    
//	    data: 		      
//	    	'<paginateWSRequest pageNumber="1" displayPages="2" xmlns="http://usps.com/ws/paginate">' +
//		        '<pages>' +
//					'<page>1</page>' +
//					'<page>2</page>' +
//					'<page>3</page>' +
//					'<page>4</page>' +
//					'<page>5</page>' +
//					'<page>6</page>' +
//				'</pages>' +
//			'</paginateWSRequest>',

	    success: function (soapResponse) {
	    	$("#responseString").text(soapResponse.toString());
	    	
	    	var s = "";
	    	$.each(soapResponse.toJSON().Body.paginateWSResponse.pages.page, function(key, value) {
	    		s += "key : " + key + ", value : " + value + "<br />";
	    	});
	    	
	    	$("#responseJSON").html(s);
	    },
	    error: function (soapResponse) {
	    	$("#responseError").text(soapResponse.toString());
	    }
	});
}

function getXMLRequestInput() {
	var xmlDomPages = document.createElement("pages");

	var pagesInputArray = $("#pagesInput").val().replace("/\r/g","").split("\n");
	$.each(pagesInputArray, function(key, value) {
		var xmlDomPage = document.createElement("page");
		var newValue = value.trim();
		if (newValue) {
			xmlDomPage.innerText = newValue;
			xmlDomPages.appendChild(xmlDomPage);			
		}
	});

	var xmlDomRoot = document.implementation.createDocument (null, 'paginateWSRequest', null);
	
	var xmlDomRootElement = xmlDomRoot.documentElement;
	xmlDomRootElement.setAttribute("pageNumber", $("#pageNumberInput").val()); 
	xmlDomRootElement.setAttribute("displayPages", $("#displayPagesInput").val()); 
	xmlDomRootElement.setAttribute("xmlns", $("#serviceNamespace").val()); 
	xmlDomRootElement.appendChild(xmlDomPages);
	
	return xmlDomRoot;
}

function resetPanels() {
	$("#responseString").text("Working on Soap Request...");
	$("#responseJSON").text("Working on Soap Request...");
	$("#responseError").text("Working on Soap Request...");
}

$(document).ready(function() {
	$("#loaded").html("JQuery working!");
});
