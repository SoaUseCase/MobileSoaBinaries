function doSoapXMLHttpRequest() {
	$("#soapResult").text("Working on soap request...");
	
    var xmlhttp = new XMLHttpRequest();
    
	if (!("withCredentials" in xmlhttp)) {
		alert("XMLHttpRequest not supported in browser!");
		return;
	}
	
    xmlhttp.open('POST', $("#serviceEndpoint").val(), true);

    // build SOAP request
    var sr = getSoapRequestInput();

	// Response handlers.
	xmlhttp.onload = function() {
		var data = xmlhttp.responseText;
		$("#soapResult").text(data);
	};
	
	xmlhttp.onerror = function() {
		var data = xmlhttp.responseText;
		alert("Error: " + data);
		$("#soapResult").text(data);
	};
    
    // Send the POST request
    xmlhttp.setRequestHeader('content-type', 'text/xml');
    xmlhttp.setRequestHeader($("#consumerIDHeaderName").val(), $("#consumerIDValue").val());
    xmlhttp.setRequestHeader($("#contextIDHeaderName").val(), $("#contextIDValue").val());
    xmlhttp.send(sr);
}

function getSoapRequestInput() {
	var retVal = "";
	var lines = $("#soapInput").val().replace("/\r/g","").split("\n");
	$.each(lines, function(key, value) {
		retVal += value.trim();
	});
	return retVal;
}

$(document).ready(function() {
	$("#loaded").html("JQuery working!");
});
