function doSoapProxy() {
	if (!document.implementation) {
		alert("Browser does not support creating xml object, thus cannot send SOAP request!");
		return;
	}
	
    var myHeaders = {};
    myHeaders["proxyForwardURL"] = $("#serviceEndpoint").val() + $("#serviceMethod").val();
    myHeaders[$("#consumerIDHeaderName").val()] = $("#consumerIDValue").val();
    myHeaders[$("#contextIDHeaderName").val()] = $("#contextIDValue").val();

	$.soap({
//	    enableLogging: true,
		url: $("#proxyURL").val(),
	    data: getXMLRequestInput(),
	    HTTPHeaders: myHeaders,         // additional http headers send with the $.ajax call, will be given to $.ajax({ headers: })

	    success: function (soapResponse) {
	    	$("#responseString").text(soapResponse.toString());
	    	
	    	var s = "";
	    	$.each(soapResponse.toJSON().Body.paginateWSResponse.pages.page, function(key, value) {
	    		s += "key : " + key + ", value : " + value + "<br />";
	    	});
	    	
	    	$("#responseJSON").html(s);
	    },
	    error: function (soapResponse) {
	    	$("#responseError").text(soapResponse.toString());
	    }
	});
}

function getXMLRequestInput() {
	var xmlDomPages = document.createElement("pages");

	var pagesInputArray = $("#pagesInput").val().replace("/\r/g","").split("\n");
	$.each(pagesInputArray, function(key, value) {
		var xmlDomPage = document.createElement("page");
		var newValue = value.trim();
		if (newValue) {
			xmlDomPage.innerText = newValue;
			xmlDomPages.appendChild(xmlDomPage);			
		}
	});

	var xmlDomRoot = document.implementation.createDocument (null, 'paginateWSRequest', null);
	
	var xmlDomRootElement = xmlDomRoot.documentElement;
	xmlDomRootElement.setAttribute("pageNumber", $("#pageNumberInput").val()); 
	xmlDomRootElement.setAttribute("displayPages", $("#displayPagesInput").val()); 
	xmlDomRootElement.setAttribute("xmlns", $("#serviceNamespace").val()); 
	xmlDomRootElement.appendChild(xmlDomPages);
	
	return xmlDomRoot;
}
