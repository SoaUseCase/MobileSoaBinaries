function paginateSuccess(data) {
	if (JSON && typeof JSON.stringify == 'function') {
		$("#resultsPanel").text(JSON.stringify(data));
	}
	else {
		$("#resultsPanel").text("Your browser does not support JSON.stringify() to display the results");
	}
}

function paginateError(data,status,error) {
	if (JSON && typeof JSON.stringify == 'function') {
		var errorString = "ERROR: there was a problem?";
		if (data.responseJSON && data.responseJSON.responseError) {
			errorString += "  " + JSON.stringify(data.responseJSON.responseError);
		}
		$("#resultsPanel").text(errorString);
	}
	else {
		$("#resultsPanel").text("Your browser does not support JSON.stringify() to display the results");
	}
}

function getPages() {
	var pagesArray = [];
	$("input[id^='pageText']").each(function(index) {
		pagesArray.push($(this).val());
	});
	return pagesArray;
}

function getRESTInput() {
	var pagesInputArray = getPages();
	var data = "{";
	
	// set pageNumber
	data += '"pageNumber" : "' + $("#pageNumberID").val() + '",';
	data += '"displayPages" : "' + $("#displayPagesID").val() + '",';
	
	// pages
	data += '"pages" : [';
	$.each(pagesInputArray, function(key, value) {
		data += '"' + value + '",';
	});
	data = data.substring(0, data.length - 1);
	data += "]}";
	
	return data;
}

function getSOAPInput() {
	var xmlDomPages = document.createElement("pages");

	var pagesInputArray = getPages();
	$.each(pagesInputArray, function(key, value) {
		var xmlDomPage = document.createElement("page");
		var newValue = value.trim();
		if (newValue) {
			xmlDomPage.innerText = newValue;
			xmlDomPages.appendChild(xmlDomPage);			
		}
	});

	var xmlDomRoot = document.implementation.createDocument (null, 'paginateWSRequest', null);
	
	var xmlDomRootElement = xmlDomRoot.documentElement;
	xmlDomRootElement.setAttribute("pageNumber", $("#pageNumberID").val()); 
	xmlDomRootElement.setAttribute("displayPages", $("#displayPagesID").val()); 
	xmlDomRootElement.setAttribute("xmlns", $("#soapNamespaceID").val()); 
	xmlDomRootElement.appendChild(xmlDomPages);
	
	return xmlDomRoot;
}

function doPaginate() {
	var paginateInputAjax = {
        success: function(data) {
			paginateSuccess(data);
        },
        error:function(data) {
            paginateError(data);
        }
    };
	
	// url
    var myHeaders = {};
	var endpointURL = $("#endpointID").val();
	if (isProxyEnabled()) {
	    var proxyForwarURLVar = endpointURL;
	    if (!isRestVisible()) {
	    	proxyForwarURLVar += $("#soapMethodID").val();
	    }
	    myHeaders["proxyForwardURL"] = proxyForwarURLVar;
		endpointURL = $("#proxyID").val();
	}
	paginateInputAjax.url = endpointURL;

	// content-type
	if (isRestVisible()) {
		contentType = "application/json";
		paginateInputAjax.contentType = contentType;
		paginateInputAjax.type = 'POST';
	}
	else {
//	    myHeaders["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8";
	}
	
	// datatype
	if (isRestVisible()) {
		paginateInputAjax.dataType = "json";
	}
	
	// variables and headers
    myHeaders[$("#consumerNameID").val()] = $("#consumerValueID").val();
    myHeaders[$("#contextNameID").val()] = $("#contextValueID").val();
	if (isRestVisible()) {
	    paginateInputAjax.headers = myHeaders;		
	}
	else {
	    paginateInputAjax.HTTPHeaders = myHeaders;		
	}
	
    // data
	if (isRestVisible()) {
	    paginateInputAjax.data = getRESTInput();
	}
	else {
	    paginateInputAjax.data = getSOAPInput();
	}

    // paginate
	if (isRestVisible()) {
	    $.ajax(paginateInputAjax);	
	}
	else {
	    $.soap(paginateInputAjax);	
	}
	
	return true;
}