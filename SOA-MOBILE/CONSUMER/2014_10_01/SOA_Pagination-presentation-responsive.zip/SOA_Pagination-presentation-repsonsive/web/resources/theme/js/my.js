var SUBSCRIBE_TYPE = '/mediaContent/change';
var MEDIA_DESKTOP = 'desktop';
var MEDIA_TABLET = 'tablet';
var MEDIA_MOBILE = 'mobile';
var LEFT_PANEL_ID = "#leftPanelNavigation";
var RIGHT_PANEL_ID = "#rightPanelSettings";
var LAST_MEDIA_CONTENT;
var SETUP = false;
var transitionMillisec = 500;
// DEFAULTS
var DEFAULT_PAGE_NUMBER = "2";
var DEFAULT_DISPLAY_PAGES = "2";
var DEFAULT_SERVICE_ENDPOINT = "http://ddatapower.usps.gov/soaPagination_provider/api/paginate";
var DEFAULT_SERVICE_ENDPOINT_SOAP = "http://ddatapower.usps.gov/soaPagination_provider_soap/ws/";
var DEFAULT_PROXY_ENDPOINT = "http://eagnmnmbd19c.usps.gov:9080/soaPagination_proxy/proxy";
var DEFAULT_CONSUMER_NAME = "uspsConsumerID";
var DEFAULT_CONTEXT_NAME = "uspsContextID";
var DEFAULT_CONSUMER_VALUE_REST = "CIDpaginationConsumer";
var DEFAULT_CONTEXT_VALUE_REST = "CxIDpagination";
var DEFAULT_CONSUMER_VALUE_SOAP = "CIDpaginationConsumerSOAP";
var DEFAULT_CONTEXT_VALUE_SOAP = "CxIDpaginationSOAP2";
var DEFAULT_SOAP_METHOD = "paginateService";
var DEFAULT_SOAP_NAMESPACE = "http://usps.com/ws/paginate";

var desktopMediaHandler = function(mediaQuery) {
	if (mediaQuery && !mediaQuery.matches) {
		return;
	}
	setLeftPanelVisible(true);
};

var tabletMediaHandler = function(mediaQuery) {
	if (mediaQuery && !mediaQuery.matches) {
		return;
	}
	setLeftPanelVisible(true);
};

var mobileMediaHandler = function(mediaQuery) {
	if (mediaQuery && !mediaQuery.matches) {
		return;
	}
	setLeftPanelVisible(false);
};

function setLeftPanelVisible(visible) {
	if (SETUP) {
		var visibleString = visible ? "open" : "close";
		$(LEFT_PANEL_ID).panel(visibleString);
	}
}

var resizeHandler = function() {
    var content = getMediaContent();
    
    if(content != LAST_MEDIA_CONTENT) {
        // Save the new state as current
    	LAST_MEDIA_CONTENT = content;

        // Announce the state change, either by a custom DOM event or via JS pub/sub
        // Since I'm in love with pub/sub, I'll assume we have a pub/sub lib available
    	$.publish(SUBSCRIBE_TYPE, [content]);
    }	
};

var resizeSubscribeHandler = function(mediaContent) {
    if(mediaContent == MEDIA_DESKTOP) {
    	desktopMediaHandler();
    }
    else if(mediaContent == MEDIA_TABLET) {
    	tabletMediaHandler();
    }
    else if(mediaContent == MEDIA_MOBILE) {
    	mobileMediaHandler();
    }	
};

function getMediaContent() {
	return window.getComputedStyle(
			document.querySelector('.myMediaValue'), 
			':before').getPropertyValue('content');
}

function setupMediaQuery() {
	if (matchMedia) {
		var desktopMediaQuery = window.matchMedia("all and (min-width: 70.063em)");
		desktopMediaQuery.addListener(desktopMediaHandler);
		desktopMediaHandler(desktopMediaQuery);

		var tabletMediaQuery = window.matchMedia("all and (min-width: 30.063em) and (max-width: 70em)");
		tabletMediaQuery.addListener(tabletMediaHandler);
		tabletMediaHandler(tabletMediaQuery);
		
		var mobileMediaQuery = window.matchMedia("all and (min-width: 0em) and (max-width: 30em)");
		mobileMediaQuery.addListener(mobileMediaHandler);
		mobileMediaHandler(mobileMediaQuery);
	}
	else {
		LAST_MEDIA_CONTENT = getMediaContent();
		tempMediaContent = LAST_MEDIA_CONTENT;
		$(window).resize(resizeHandler);
		$.subscribe(SUBSCRIBE_TYPE, resizeSubscribeHandler);
	}
}

var addCheckText = function(tempDefaultValue) {
	var defaultValue = "";
	if (tempDefaultValue && !tempDefaultValue.target) {
		defaultValue = tempDefaultValue;
	}
	var parentId = "#myCheckTextGroup";
	var lastIdString = $(parentId + " div.myCheckText:last-child input[type='text']").attr("id");
	var nextIndex = 1;
	if (lastIdString) {
		var idNumString = lastIdString.substring("pageText".length);
		nextIndex = parseInt(idNumString) + 1;
	}
	var htmlContent = 	"<div class='ui-grid-b myCheckText'>" +
						    "<div class='ui-block-a'>" +
						        "<label for='pageCheckbox" + nextIndex + "'>&nbsp;</label>" +
						        "<input type='checkbox' id='pageCheckbox" + nextIndex + "' name='pageCheckbox" + nextIndex + "' />" +
						    "</div>" +
						    "<div class='ui-block-b'>" +
						    	"<input id='pageText" + nextIndex + "' type='text' value='" + defaultValue + "' />" +
						    "</div>" +
						"</div>";
	$(parentId).append(htmlContent).trigger('create');
};

var removeCheckText = function() {
	$("div#myCheckTextGroup input[type='checkbox']:checked").each(function(index) {
		$(this).closest("div.myCheckText").remove();
	});
};

function isProxyEnabled() {
    var state = $("#proxyFlipID").val();
    if (state == "yes") {
    	return true;
    }
    return false;
}

function proxyEnabled() {	
	var proxySettingsPanelID = "#proxySettingsPanel";
	if (isProxyEnabled()) {
		$(proxySettingsPanelID).show(transitionMillisec);
	}
	else {
		$(proxySettingsPanelID).hide(transitionMillisec);
	}
}

function setupEvents() {
	$("#addCheckText").click(addCheckText);
	$("#removeCheckText").click(removeCheckText);
	$("#proxyFlipID").change(proxyEnabled);
}

function isRestVisible() {
	return $("#restTitle").is(":visible");
}

function setSOAPVisible(isVisible) {
	var restTitleID = "#restTitle";
	var soapTitleID = "#soapTitle";
	var soapMethodPanelID = "#soapMethodPanel";
	var soapNamespacePanelID = "#soapNamespacePanel";
	if (isVisible) {
		$(restTitleID).hide(transitionMillisec);
		$(soapTitleID).show(transitionMillisec);
		$(soapMethodPanelID).show(transitionMillisec);
		$(soapNamespacePanelID).show(transitionMillisec);
		setVariablesForSOAP(true);
	}
	else {
		$(restTitleID).show(transitionMillisec);
		$(soapTitleID).hide(transitionMillisec);
		$(soapMethodPanelID).hide(transitionMillisec);
		$(soapNamespacePanelID).hide(transitionMillisec);
		setVariablesForSOAP(false);
	}
}

function setVariablesForSOAP(isSoap) {
	var consumerID = "#consumerValueID";
	var contextID = "#contextValueID";
	var endpointID = "#endpointID";

	if (isSoap) {
		$(consumerID).val(DEFAULT_CONSUMER_VALUE_SOAP);	
		$(contextID).val(DEFAULT_CONTEXT_VALUE_SOAP);
		$(endpointID).val(DEFAULT_SERVICE_ENDPOINT_SOAP);
	}
	else {
		$(consumerID).val(DEFAULT_CONSUMER_VALUE_REST);	
		$(contextID).val(DEFAULT_CONTEXT_VALUE_REST);
		$(endpointID).val(DEFAULT_SERVICE_ENDPOINT);
	}
}

function setupDefaultValues() {
	// endpoints
	$("#endpointID").val(DEFAULT_SERVICE_ENDPOINT);
	$("#proxyID").val(DEFAULT_PROXY_ENDPOINT);
	// variables
	$("#consumerNameID").val(DEFAULT_CONSUMER_NAME);
	$("#contextNameID").val(DEFAULT_CONTEXT_NAME);
	setVariablesForSOAP(false);
	// paginate
	$("#pageNumberID").val(DEFAULT_PAGE_NUMBER);
	$("#displayPagesID").val(DEFAULT_DISPLAY_PAGES);
	for (var i = 1; i <= 10; i++) {
		addCheckText(i);
	}
	// soap
	$("#soapMethodID").val(DEFAULT_SOAP_METHOD);
	$("#soapNamespaceID").val(DEFAULT_SOAP_NAMESPACE);
}

$( document ).ready(function() {
	setupMediaQuery();
	$(LEFT_PANEL_ID).panel().enhanceWithin();
	$(RIGHT_PANEL_ID).panel().enhanceWithin();
	SETUP = true;
	setLeftPanelVisible($( window ).width() > 480);
	
	setupEvents();
	setupDefaultValues();
});
